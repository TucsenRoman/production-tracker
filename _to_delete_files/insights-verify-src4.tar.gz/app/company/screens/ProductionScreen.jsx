"use client";

import React, { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Check,
  ClipboardCheck,
  Plus,
  SlidersHorizontal,
} from "lucide-react";

import {
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  Modal,
  Segmented,
  StickyFadeHeader,
  cx,
} from "../../components/ui";
import {
  STATIONS,
  behindStock,
  normalizeItem,
  refillQty,
  stockIn,
  shiftDate,
  weekOf,
} from "../../lib/domain";

/**
 * Console-side production targets.
 *
 * The flow this screen runs, in the order a manager actually thinks it:
 *
 *   1. here is what is on the floor
 *   2. here is the min and the max it should sit between
 *   3. so here is what you should plan — and how much of that is a run
 *      versus stock already sitting in the back
 *   4. disagree? change the amount, or change the min and max themselves
 *
 * Every number comes from the domain's own vocabulary rather than a private
 * one invented here: `threshold` is the min, `max` the fill target,
 * `refillQty` the gap between the floor and that max, `behindStock` what
 * could be put out without making anything at all.
 *
 * That last one is why the recommendation is split. "Plan 82 lb" is wrong
 * when 42 lb of it is already in the freezer — the honest answer is move 42
 * and make 40, and a screen that says 82 sends someone to smoke bacon that
 * already exists.
 *
 * The day-by-day strip stayed on the floor Board, where a shift is genuinely
 * working one day at a time. A manager is deciding what to commit, not what
 * is happening at 2pm on Thursday.
 */

const STATE = {
  /* Nothing on the floor is not the same problem as being under par: one is
   * a case a customer is standing in front of, the other is a number
   * trending the wrong way. It gets its own state, its own rank and the only
   * danger tone on the screen. */
  out: { label: "Out", tone: "danger", rank: 0 },
  below: { label: "Below min", tone: "warn", rank: 1 },
  make: { label: "Needs a run", tone: "neutral", rank: 2 },
  move: { label: "Move from back", tone: "cold", rank: 3 },
  planned: { label: "Planned", tone: "info", rank: 4 },
  full: { label: "On hand", tone: "ok", rank: 5 },
};

export default function ProductionScreen({
  schedule,
  inventory,
  batches = [],
  today,
  onSetRange,
  onAddTask,
}) {
  const [tab, setTab] = useState("attention");
  const [rangesOpen, setRangesOpen] = useState(false);

  const week = useMemo(() => weekOf(today), [today]);
  /* Where an accepted plan lands: today if it's a production day, else the
   * next one. A manager shouldn't have to pick a date to say "yes, make it". */
  const defaultDay = useMemo(() => {
    const day = week.find((d) => d.isProductionDay && d.key >= today);
    return day ? day.key : today;
  }, [week, today]);

  const rows = useMemo(() => {
    /* What is already committed against each product: runs booked on days
     * that haven't happened, plus batches physically in flight. Today's
     * schedule rows are skipped because adding one on today spawns a batch
     * too, and counting both would double-book a product against itself. */
    const committed = new Map();
    const bump = (product, n) =>
      committed.set(product, (committed.get(product) || 0) + n);

    /* A rolling window forward, NOT the rest of the calendar week. On a
     * Friday the current week has no production days left, so a week-bounded
     * scan could never see a plan at all and everything read as unplanned —
     * including runs booked for Monday. A plan is a plan regardless of which
     * week it falls in. Today is excluded because adding a run on today
     * spawns a batch too, and both would count. */
    for (let i = 1; i <= 7; i += 1) {
      const key = shiftDate(today, i);
      const dow = new Date(`${key}T00:00:00`).getDay();
      if (dow === 0 || dow === 6) continue; // no production at the weekend
      for (const station of STATIONS) {
        for (const t of (schedule[key] || {})[station] || []) {
          bump(t.text, Number(t.qty) || 0);
        }
      }
    }
    for (const b of batches) {
      if (b.finalWeight != null) continue; // already landed in stock
      bump(b.product, Number(b.boxWeight ?? b.estWeight) || 0);
    }

    return inventory
      .map(normalizeItem)
      .map((item) => {
        const floor = stockIn(item, "floor");
        const behind = behindStock(item);
        const refill = refillQty(item);
        const fromBack = Math.min(refill, behind);
        const toMake = Math.max(0, +(refill - behind).toFixed(1));
        const planned = committed.get(item.product) || 0;

        let state;
        if (refill <= 0) state = "full";
        else if (planned >= toMake && toMake > 0) state = "planned";
        else if (floor <= 0) state = "out";
        else if (floor < item.threshold) state = "below";
        else if (toMake > 0) state = "make";
        else state = "move";

        return { item, floor, behind, refill, fromBack, toMake, planned, state };
      })
      .sort(
        (a, b) =>
          STATE[a.state].rank - STATE[b.state].rank ||
          b.refill - a.refill ||
          a.item.product.localeCompare(b.item.product),
      );
  }, [inventory, schedule, batches, today]);

  /* Three states a product can be in, as tabs rather than one long mixed
   * list: something you still have to decide about, something already
   * committed, and something that needs nothing. They're read at different
   * moments — you work the first, check the second, and ignore the third. */
  const groups = useMemo(
    () => ({
      attention: rows.filter((r) => ["out", "below", "make", "move"].includes(r.state)),
      planned: rows.filter((r) => r.state === "planned"),
      stocked: rows.filter((r) => r.state === "full"),
    }),
    [rows],
  );

  const shown = groups[tab] || [];
  const totalToMake = groups.attention.reduce(
    (n, r) => n + Math.max(0, r.toMake - r.planned),
    0,
  );
  const totalToMove = groups.attention.reduce((n, r) => n + r.fromBack, 0);
  const outCount = rows.filter((r) => r.state === "out").length;
  const belowMin = rows.filter((r) => r.state === "below").length;

  return (
    <div>
      <StickyFadeHeader pad={28}>
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <Segmented
            fade
            value={tab}
            onChange={setTab}
            options={[
              {
                value: "attention",
                label: "Needs a plan",
                icon: AlertTriangle,
                count: groups.attention.length || undefined,
              },
              {
                value: "planned",
                label: "Planned",
                icon: ClipboardCheck,
                count: groups.planned.length || undefined,
              },
              {
                value: "stocked",
                label: "On hand",
                icon: Check,
                count: groups.stocked.length || undefined,
              },
            ]}
          />

          <div className="flex items-center gap-3 shrink-0">
            <span className="text-xs text-ink-3 tnum">
              {outCount > 0 && (
                <span className="text-danger font-medium">{outCount} out · </span>
              )}
              {belowMin > 0 && (
                <span className="text-warn font-medium">{belowMin} below min · </span>
              )}
              {Math.round(totalToMove)} lb to move · {Math.round(totalToMake)} lb to make
            </span>
            <Button
              size="sm"
              variant="secondary"
              icon={SlidersHorizontal}
              onClick={() => setRangesOpen(true)}
            >
              Min &amp; max
            </Button>
          </div>
        </div>
      </StickyFadeHeader>

      {shown.length === 0 ? (
        <Card>
          <EmptyState
            icon={Check}
            title={
              tab === "attention"
                ? "Nothing waiting on a decision"
                : tab === "planned"
                  ? "Nothing planned yet"
                  : "Nothing fully on hand"
            }
            description={
              tab === "attention"
                ? "Every product is either planned for or already on hand."
                : tab === "planned"
                  ? "Runs you add from the other tab show up here."
                  : "Every case is below its max right now."
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-3">
          {shown.map((row) => (
            <PlanCard
              key={row.item.product}
              row={row}
              defaultDay={defaultDay}
              onAddTask={onAddTask}
            />
          ))}
        </div>
      )}

      {rangesOpen && (
        <RangesModal
          inventory={inventory}
          onSetRange={onSetRange}
          onClose={() => setRangesOpen(false)}
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ parts -- */

/**
 * The case, drawn as a case: a column from empty to max, filled to where the
 * floor actually is, with the min drawn across it as a line you can be under.
 * The pale segment above the fill is what accepting this plan would add, so
 * the decision and its effect are the same picture.
 */
function Gauge({ floor, min, max, adding }) {
  const pct = (n) => (max > 0 ? Math.max(0, Math.min(100, (n / max) * 100)) : 0);
  return (
    <div className="relative w-6 h-14 shrink-0 rounded-md bg-inset border border-line overflow-hidden">
      {adding > 0 && (
        <span
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 bg-cold-soft"
          style={{ height: `${pct(floor + adding)}%` }}
        />
      )}
      <span
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 bg-ink-2"
        style={{ height: `${pct(floor)}%` }}
      />
      <span
        aria-hidden="true"
        title={`Minimum ${min}`}
        className="absolute inset-x-0 h-0.5 bg-warn"
        style={{ bottom: `${pct(min)}%` }}
      />
    </div>
  );
}

function PlanCard({ row, defaultDay, onAddTask }) {
  const { item, floor, refill, fromBack, toMake, planned, state } = row;
  const s = STATE[state];

  const stillToMake = Math.max(0, Math.round(toMake - planned));
  const [qty, setQty] = useState(String(stillToMake || Math.round(refill)));
  const [station, setStation] = useState(STATIONS[0]);
  const n = Number(qty) || 0;

  /* One line, not four. The card was carrying "Plan N to fill the case", then
   * a move line, a make line and a planned line, each with its own icon — four
   * sentences to say one thing, twenty-four times down a grid. The verbs are
   * what matter; the arithmetic behind them is on the gauge. */
  const summary = [
    stillToMake > 0 && `make ${stillToMake}`,
    fromBack > 0 && `move ${Math.round(fromBack)} from back`,
    planned > 0 && `${Math.round(planned)} planned`,
  ].filter(Boolean);

  return (
    <div className="flex flex-col gap-2 border border-line rounded-md bg-surface px-3 py-2.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-medium text-ink min-w-0 truncate">
          {item.product}
        </span>
        <Badge tone={s.tone} icon={state === "full" ? Check : undefined}>
          {s.label}
        </Badge>
      </div>

      <div className="flex items-center gap-2.5">
        <Gauge floor={floor} min={item.threshold} max={item.max} adding={n} />
        <div className="min-w-0 flex-1">
          {/* The range is read here and edited in the Min & max list — one
           *  product's band is a setting, not a per-card decision, and the
           *  inline editor was the heaviest thing on every card. */}
          <p className="tnum leading-none">
            <span className="text-xl font-semibold text-ink">{floor}</span>
            <span className="text-xs text-ink-3">
              {" "}
              / {item.threshold}&ndash;{item.max} {item.unit}
            </span>
          </p>
          <p className="mt-1 text-xs text-ink-3 tnum truncate">
            {summary.length ? summary.join(" · ") : "nothing to plan"}
          </p>
        </div>
      </div>

      {refill > 0 && (
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="w-14 shrink-0">
            <Input
              type="number"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              className="tnum"
              aria-label={`Amount to plan for ${item.product}`}
            />
          </span>
          <Segmented
            size="sm"
            value={station}
            onChange={setStation}
            options={STATIONS.map((st) => ({ value: st, label: st }))}
          />
          <Button
            size="sm"
            variant={state === "below" ? "primary" : "secondary"}
            icon={Plus}
            disabled={n <= 0}
            onClick={() => onAddTask(defaultDay, station, item.product, n)}
          >
            Add
          </Button>
        </div>
      )}
    </div>
  );
}

/**
 * Every product's band in one place. A min and a max are settings — they're
 * set once and then left alone — so they don't belong on a card a manager
 * reads twenty-four times a day looking for what to run next.
 *
 * Edits commit on blur or Enter and only when a value actually changed, so
 * tabbing through the list doesn't fire a write per row.
 */
/* Mutually exclusive, so the counts add up to the catalogue. "Under min"
 * deliberately excludes the empty ones — those are their own bucket. */
const RANGE_FILTERS = [
  { id: "all", label: "All", match: () => true },
  { id: "out", label: "Out", match: (i) => stockIn(i, "floor") <= 0 },
  {
    id: "under",
    label: "Under min",
    match: (i) => stockIn(i, "floor") > 0 && stockIn(i, "floor") < i.threshold,
  },
  {
    id: "in",
    label: "In range",
    match: (i) => stockIn(i, "floor") >= i.threshold && stockIn(i, "floor") < i.max,
  },
  { id: "over", label: "At max", match: (i) => stockIn(i, "floor") >= i.max },
];

/** Which value each sortable column reads off a product. */
const RANGE_COLUMNS = {
  product: (i) => i.product,
  floor: (i) => stockIn(i, "floor"),
  min: (i) => i.threshold,
  max: (i) => i.max,
};

function RangesModal({ inventory, onSetRange, onClose }) {
  const [q, setQ] = useState("");
  /* Alphabetical to start — the list is for finding a known product. Clicking
   * a number column starts DESCENDING, because the reason to sort by "on
   * floor" or "min" is almost always to see the extremes first, and making
   * someone click twice to get there is a small tax paid every time. */
  const [sort, setSort] = useState({ key: "product", dir: "asc" });
  const [filter, setFilter] = useState("all");

  const onSort = (key) =>
    setSort((prev) =>
      prev.key === key
        ? { key, dir: prev.dir === "asc" ? "desc" : "asc" }
        : { key, dir: key === "product" ? "asc" : "desc" },
    );

  const searched = inventory
    .map(normalizeItem)
    .filter((i) => i.product.toLowerCase().includes(q.trim().toLowerCase()));

  /* Counts come off the searched set, not the whole catalogue, so a filter
   * chip never promises rows the search has already excluded. */
  const counts = Object.fromEntries(
    RANGE_FILTERS.map((f) => [f.id, searched.filter(f.match).length]),
  );
  const active = RANGE_FILTERS.find((f) => f.id === filter) || RANGE_FILTERS[0];

  const items = searched
    .filter(active.match)
    .sort((a, b) => {
      const dir = sort.dir === "asc" ? 1 : -1;
      const read = RANGE_COLUMNS[sort.key] || RANGE_COLUMNS.product;
      const va = read(a);
      const vb = read(b);
      const cmp =
        typeof va === "string" ? va.localeCompare(vb) : va - vb;
      // Product name as the tiebreak, so equal numbers never reshuffle.
      return dir * cmp || a.product.localeCompare(b.product);
    });

  return (
    <Modal
      open
      size="lg"
      icon={SlidersHorizontal}
      title="Min & max by product"
      onClose={onClose}
      footer={
        <Button variant="primary" onClick={onClose}>
          Done
        </Button>
      }
    >
      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Find a product…"
      />

      <div className="mt-2.5">
        <Segmented
          fade
          size="sm"
          value={filter}
          onChange={setFilter}
          options={RANGE_FILTERS.map((f) => ({
            value: f.id,
            label: f.label,
            count: f.id === "all" ? undefined : counts[f.id] || undefined,
          }))}
        />
      </div>

      <div className="mt-3 flex items-center gap-2 px-1">
        <SortHeader label="Product" col="product" sort={sort} onSort={onSort} className="flex-1 justify-start" />
        <SortHeader label="On floor" col="floor" sort={sort} onSort={onSort} className="w-16 justify-end" />
        <SortHeader label="Min" col="min" sort={sort} onSort={onSort} className="w-16 justify-center" />
        <SortHeader label="Max" col="max" sort={sort} onSort={onSort} className="w-16 justify-center" />
      </div>

      <div className="mt-1 border-y border-line max-h-[50vh] overflow-y-auto">
        {items.length === 0 ? (
          <p className="px-1 py-6 text-center text-xs text-ink-4">
            {q ? `No product matches “${q}”.` : "Nothing in this state."}
          </p>
        ) : (
          <ul className="divide-y divide-line">
            {items.map((item) => (
              <RangeRow key={item.product} item={item} onSetRange={onSetRange} />
            ))}
          </ul>
        )}
      </div>
    </Modal>
  );
}

function SortHeader({ label, col, sort, onSort, className }) {
  const active = sort.key === col;
  const Icon = sort.dir === "asc" ? ArrowUp : ArrowDown;
  return (
    <button
      type="button"
      onClick={() => onSort(col)}
      aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}
      className={cx(
        "flex items-center gap-1 shrink-0 text-xs font-medium transition-colors",
        active ? "text-ink" : "text-ink-3 hover:text-ink",
        className,
      )}
    >
      {label}
      {/* Only the active column shows a direction — an arrow on every header
       *  reads as decoration and stops meaning anything. */}
      {active && <Icon size={11} className="shrink-0" />}
    </button>
  );
}

function RangeRow({ item, onSetRange }) {
  const [min, setMin] = useState(String(item.threshold));
  const [max, setMax] = useState(String(item.max));
  const floor = stockIn(item, "floor");

  const commit = () => {
    const t = Number(min) || 0;
    const m = Number(max) || 0;
    if (t === item.threshold && m === item.max) return;
    onSetRange(item.product, { threshold: t, max: m });
  };
  const onKey = (e) => {
    if (e.key === "Enter") e.currentTarget.blur();
  };

  return (
    <li className="flex items-center gap-2 px-1 py-1.5">
      <span className="flex-1 min-w-0 truncate text-sm text-ink">{item.product}</span>
      <span
        className={cx(
          "w-16 text-right shrink-0 text-xs tnum",
          floor <= 0
            ? "text-danger font-semibold"
            : floor < item.threshold
              ? "text-warn font-medium"
              : "text-ink-4",
        )}
      >
        {floor}
      </span>
      <span className="w-16 shrink-0">
        <Input
          type="number"
          value={min}
          onChange={(e) => setMin(e.target.value)}
          onBlur={commit}
          onKeyDown={onKey}
          className="tnum"
          aria-label={`Minimum for ${item.product}`}
        />
      </span>
      <span className="w-16 shrink-0">
        <Input
          type="number"
          value={max}
          onChange={(e) => setMax(e.target.value)}
          onBlur={commit}
          onKeyDown={onKey}
          className="tnum"
          aria-label={`Maximum for ${item.product}`}
        />
      </span>
    </li>
  );
}
