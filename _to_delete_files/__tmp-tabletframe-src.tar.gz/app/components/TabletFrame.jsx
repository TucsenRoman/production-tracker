"use client";

import React, { createContext, useEffect, useState } from "react";

/**
 * Read by AppShell to know it's being rendered inside a device mockup
 * rather than as a real page — see the `framed` check in AppShell.jsx.
 * Defaults to false, so CompanyConsole (which never renders inside a
 * TabletFrame) is completely unaffected.
 */
export const TabletFrameContext = createContext(false);

// iPad Air's own landscape logical resolution — comfortably above Tailwind's
// 1024px `lg` breakpoint, so the framed content renders the real desktop/
// rail layout, the same as it would on an actual production-floor tablet.
const FRAME_W = 1180;
const FRAME_H = 820;
const BEZEL = 18;
const OUTER_RADIUS = 40;
const INNER_RADIUS = 24;
const VIEWPORT_MARGIN = 48;
const MIN_SCALE = 0.35;

/**
 * Wraps the floor app in a static tablet mockup for demos — a bezel, a
 * front-camera dot, and a fixed 1180x820 content area — so it reads as
 * "this is the tablet experience" at a glance, including in a screenshot.
 * Purely visual chrome outside the app's own Notion DNA component system;
 * only used from app/page.tsx. CompanyConsole is never wrapped in this and
 * stays a normal, fully responsive web page.
 *
 * Scales the whole device down (CSS transform, never re-flowing the app's
 * own layout) to fit smaller browser windows, computed from window size on
 * mount and on resize — matches the measure-don't-guess pattern the rest of
 * this codebase already uses for the mobile header height and the
 * RoleSwitcher's viewport clamping.
 */
export default function TabletFrame({ children }) {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const totalW = FRAME_W + BEZEL * 2;
    const totalH = FRAME_H + BEZEL * 2;

    const recompute = () => {
      const availW = window.innerWidth - VIEWPORT_MARGIN * 2;
      const availH = window.innerHeight - VIEWPORT_MARGIN * 2;
      const next = Math.min(1, availW / totalW, availH / totalH);
      setScale(Math.max(MIN_SCALE, next));
    };

    recompute();
    window.addEventListener("resize", recompute);
    return () => window.removeEventListener("resize", recompute);
  }, []);

  const totalW = FRAME_W + BEZEL * 2;
  const totalH = FRAME_H + BEZEL * 2;

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-center gap-3 p-6 overflow-auto"
      style={{ background: "#e5e0d5" }}
    >
      <div style={{ width: totalW * scale, height: totalH * scale }}>
        <div
          style={{
            width: totalW,
            height: totalH,
            transform: `scale(${scale})`,
            transformOrigin: "top left",
            background: "#2a2724",
            borderRadius: OUTER_RADIUS,
            padding: BEZEL,
            position: "relative",
            boxShadow: "0 24px 60px -20px rgba(30,25,20,0.35)",
          }}
        >
          <div
            aria-hidden="true"
            style={{
              position: "absolute",
              top: 6,
              left: "50%",
              transform: "translateX(-50%)",
              width: 6,
              height: 6,
              borderRadius: 9999,
              background: "#4a453f",
            }}
          />
          <div
            style={{
              width: FRAME_W,
              height: FRAME_H,
              borderRadius: INNER_RADIUS,
              overflow: "hidden",
              background: "#fff",
            }}
          >
            <TabletFrameContext.Provider value={true}>{children}</TabletFrameContext.Provider>
          </div>
        </div>
      </div>
      <p className="text-xs" style={{ color: "#8f897c" }}>
        Floor terminal — tablet preview
      </p>
    </div>
  );
}
