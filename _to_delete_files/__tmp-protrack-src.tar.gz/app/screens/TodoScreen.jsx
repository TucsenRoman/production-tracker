"use client";

import React, { useMemo, useState } from "react";
import {
  AlertTriangle,
  Calendar,
  CalendarClock,
  CheckCircle2,
  Circle,
  ClipboardList,
  Plus,
  Trash2,
  Users,
} from "lucide-react";

import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  IconButton,
  Input,
  Modal,
  Segmented,
  StatCard,
  StatGrid,
  cx,
} from "../components/ui";
import {
  PRIORITY_LABEL,
  PRIORITY_TONE,
  TASK_CATEGORIES,
  TASK_PRIORITIES,
  categoryIcon,
  daysUntil,
  dueLabel,
  isManager,
  sortTasks,
  todayKey,
  visibleTasks,
} from "../lib/domain";
import { useStaff } from "../lib/staff";

/**
 * The four things worth knowing at a glance. Each tile is also the filter
 * that explains it — same convention as the Inventory overview row.
 */
const FOCUS = [
  { id: "open", label: "Open", icon: ClipboardList, tone: "primary", hint: "on the list" },
  {
    id: "dueToday",
    label: "Due today",
    icon: CalendarClock,
    tone: "warn",
    hint: "wrap these up first",
    match: (t) => !t.completed && t.dueDate != null && daysUntil(t.dueDate) === 0,
  },
  {
    id: "overdue",
    label: "Overdue",
    icon: AlertTriangle,
    tone: "danger",
    hint: "past their date",
    match: (t) => !t.completed && t.dueDate != null && daysUntil(t.dueDate) < 0,
  },
  {
    id: "completedToday",
    label: "Completed today",
    icon: CheckCircle2,
    tone: "ok",
    hint: "nice work",
    match: (t) => t.completed && t.completedAt?.slice(0, 10) === todayKey(),
  },
];
FOCUS[0].match = (t) => !t.completed;

/* ------------------------------------------------------------------ Row -- */

function TaskRow({ task, staff, canManage, onToggle, onRemove }) {
  const Icon = categoryIcon(task.category);
  const overdue = !task.completed && task.dueDate != null && daysUntil(task.dueDate) < 0;
  const dueToday = !task.completed && task.dueDate != null && daysUntil(task.dueDate) === 0;
  const assignee = task.assignedTo ? staff.find((s) => s.id === task.assignedTo) : null;

  return (
    <li
      className={cx(
        "flex items-start gap-3 py-3 px-1 -mx-1 rounded-md transition-colors",
        task.completed ? "opacity-60" : "hover:bg-faint"
      )}
    >
      <button
        type="button"
        aria-label={task.completed ? `Mark "${task.title}" not done` : `Mark "${task.title}" done`}
        onClick={onToggle}
        className={cx(
          "mt-0.5 shrink-0 transition-colors",
          task.completed ? "text-ok" : "text-ink-4 hover:text-ink-2"
        )}
      >
        {task.completed ? <CheckCircle2 size={19} /> : <Circle size={19} />}
      </button>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 flex-wrap">
          <Icon size={13} className="text-icon-2 shrink-0" />
          <p className={cx("text-sm font-medium text-ink", task.completed && "line-through text-ink-3")}>
            {task.title}
          </p>
          {!task.completed && task.priority !== "normal" && (
            <Badge tone={PRIORITY_TONE[task.priority]}>{PRIORITY_LABEL[task.priority]}</Badge>
          )}
        </div>

        {task.note && <p className="mt-0.5 text-xs text-ink-3 leading-relaxed">{task.note}</p>}

        <div className="mt-1.5 flex items-center flex-wrap gap-x-3 gap-y-1 text-xs text-ink-3">
          <span className="inline-flex items-center gap-1.5">
            {assignee ? (
              <>
                <span className="flex items-center justify-center w-4 h-4 rounded-full bg-inset text-[9px] font-semibold text-ink-2 shrink-0">
                  {assignee.initials}
                </span>
                {assignee.name.split(" ")[0]}
              </>
            ) : (
              <>
                <Users size={11} className="shrink-0" /> Anyone on shift
              </>
            )}
          </span>

          {task.dueDate && (
            <span
              className={cx(
                "inline-flex items-center gap-1 font-medium",
                overdue ? "text-danger" : dueToday ? "text-warn" : "text-ink-3"
              )}
            >
              <Calendar size={11} /> {dueLabel(task.dueDate)}
            </span>
          )}

          <span className="text-ink-4">
            {task.completed
              ? task.completedBy
                ? `Done by ${task.completedBy.split(" ")[0]}`
                : "Done"
              : `Assigned by ${task.createdBy.split(" ")[0]}`}
          </span>
        </div>
      </div>

      {canManage && (
        <IconButton
          label={`Remove "${task.title}"`}
          icon={Trash2}
          onClick={onRemove}
          className="shrink-0"
        />
      )}
    </li>
  );
}

/* --------------------------------------------------------------- Add form -- */

function AddTaskModal({ staff, onCancel, onSave }) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(TASK_CATEGORIES[0].id);
  const [priority, setPriority] = useState("normal");
  const [assignedTo, setAssignedTo] = useState("anyone");
  const [dueDate, setDueDate] = useState("");
  const [note, setNote] = useState("");

  const ready = title.trim().length > 1;

  const save = () => {
    if (!ready) return;
    onSave({
      title: title.trim(),
      category,
      priority,
      assignedTo: assignedTo === "anyone" ? null : assignedTo,
      dueDate: dueDate || null,
      note: note.trim() || null,
    });
  };

  return (
    <Modal
      open
      onClose={onCancel}
      title="New task"
      icon={ClipboardList}
      footer={
        <>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button variant="primary" icon={Plus} disabled={!ready} onClick={save}>
            Add task
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="What needs doing">
          <Input
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
            placeholder="e.g. Restock bacon on the floor"
          />
        </Field>

        <Field label="Category">
          <Segmented
            size="sm" scroll value={category} onChange={setCategory}
            options={TASK_CATEGORIES.map((c) => ({ value: c.id, label: c.label, icon: c.icon }))}
          />
        </Field>

        <Field label="Priority">
          <Segmented
            size="sm" value={priority} onChange={setPriority}
            options={TASK_PRIORITIES.map((p) => ({ value: p, label: PRIORITY_LABEL[p] }))}
          />
        </Field>

        <Field label="Assign to" hint="Leave on Anyone to let whoever's free pick it up.">
          <Segmented
            size="sm" scroll value={assignedTo} onChange={setAssignedTo}
            options={[
              { value: "anyone", label: "Anyone", icon: Users },
              ...staff.map((s) => ({ value: s.id, label: s.name.split(" ")[0] })),
            ]}
          />
        </Field>

        <Field label="Due date" hint="Optional.">
          <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </Field>

        <Field label="Note" hint="Optional — quantities, where to find something.">
          <Input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. 18 lb in the freezer, ready to bag"
          />
        </Field>
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------------- Screen -- */

export default function TodoScreen({ todos, user, onAdd, onToggle, onRemove }) {
  const { staff } = useStaff();
  const canManage = isManager(user);

  const [tab, setTab] = useState("open");
  const [category, setCategory] = useState("all");
  const [quick, setQuick] = useState(null);
  const [adding, setAdding] = useState(false);

  const base = useMemo(() => visibleTasks(todos, user), [todos, user]);

  const counts = useMemo(
    () => Object.fromEntries(FOCUS.map((f) => [f.id, base.filter(f.match).length])),
    [base]
  );

  const pickStat = (id) => {
    if (id === "open") {
      setTab("open");
      setQuick(null);
    } else if (id === "completedToday") {
      setTab("completed");
      setQuick(null);
    } else {
      setTab("open");
      setQuick((q) => (q === id ? null : id));
    }
  };

  const activeStat = tab === "completed" ? "completedToday" : quick || "open";

  const categoriesPresent = useMemo(
    () => TASK_CATEGORIES.filter((c) => base.some((t) => t.category === c.id)),
    [base]
  );

  const filtered = useMemo(() => {
    return base.filter((t) => {
      if (tab === "open" && t.completed) return false;
      if (tab === "completed" && !t.completed) return false;
      if (category !== "all" && t.category !== category) return false;
      if (quick === "dueToday" && !(t.dueDate != null && daysUntil(t.dueDate) === 0)) return false;
      if (quick === "overdue" && !(t.dueDate != null && daysUntil(t.dueDate) < 0)) return false;
      return true;
    });
  }, [base, tab, category, quick]);

  const ordered = sortTasks(filtered);

  return (
    <div className="space-y-5">
      <StatGrid>
        {FOCUS.map((f) => (
          <StatCard
            key={f.id}
            icon={f.icon}
            label={f.label}
            value={counts[f.id]}
            tone={counts[f.id] ? f.tone : "neutral"}
            hint={f.hint}
            active={activeStat === f.id}
            onClick={() => pickStat(f.id)}
          />
        ))}
      </StatGrid>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <Segmented
            value={tab}
            onChange={(v) => {
              setTab(v);
              setQuick(null);
            }}
            options={[
              { value: "open", label: "Open", icon: ClipboardList },
              { value: "completed", label: "Completed", icon: CheckCircle2 },
            ]}
          />
          {categoriesPresent.length > 1 && (
            <Segmented
              size="sm" scroll value={category} onChange={setCategory}
              options={[
                { value: "all", label: "All" },
                ...categoriesPresent.map((c) => ({ value: c.id, label: c.label, icon: c.icon })),
              ]}
            />
          )}
        </div>

        {canManage && (
          <Button variant="primary" icon={Plus} onClick={() => setAdding(true)}>
            New task
          </Button>
        )}
      </div>

      {ordered.length === 0 ? (
        <Card>
          <EmptyState
            icon={tab === "completed" ? CheckCircle2 : ClipboardList}
            title={tab === "completed" ? "Nothing completed here yet" : "Nothing on the list"}
            description={
              tab === "completed"
                ? "Finished tasks show up here."
                : canManage
                  ? "Add a task for the floor to pick up."
                  : "Check back once management assigns something."
            }
            action={
              canManage && tab === "open" ? (
                <Button icon={Plus} onClick={() => setAdding(true)}>
                  New task
                </Button>
              ) : null
            }
          />
        </Card>
      ) : (
        <ul className="divide-y divide-line border-b border-line">
          {ordered.map((task) => (
            <TaskRow
              key={task.id}
              task={task}
              staff={staff}
              canManage={canManage}
              onToggle={() => onToggle(task.id)}
              onRemove={() => onRemove(task.id)}
            />
          ))}
        </ul>
      )}

      {adding && (
        <AddTaskModal
          staff={staff}
          onCancel={() => setAdding(false)}
          onSave={(task) => {
            onAdd(task, user);
            setAdding(false);
          }}
        />
      )}
    </div>
  );
}
