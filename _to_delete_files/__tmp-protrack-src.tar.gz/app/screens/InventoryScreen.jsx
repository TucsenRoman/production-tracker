"use client";

import React, { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  ArrowRightCircle,
  CheckCircle2,
  CloudOff,
  Package,
  PackageCheck,
  PackageX,
  Plus,
  RefreshCw,
  SlidersHorizontal,
  Snowflake,
  Store,
  Timer,
  Trash2,
  X,
} from "lucide-react";

import {
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  Input,
  Modal,
  SearchInput,
  Segmented,
  SkeletonRows,
  StatCard,
  StatGrid,
  cx,
} from "../components/ui";
import {
  COVER_WARN_DAYS,
  behindStock,
  canPutOut,
  capacityFor,
  PRODUCT_TYPES,
  STOCK_STATES,
  coverTone,
  daysOfCover,
  defaultThreshold,
  floorDeficit,
  potentialCover,
  productType,
  refillQty,
  relativeTime,
  stateLabel,
  stockIn,
  stockStatus,
  totalStock,
} from "../lib/domain";

const STATE_ICON = { made: PackageCheck, freezer: Snowflake, floor: Store };

/** Traffic light on the floor count: nothing / below par / at or over par. */
const FLOOR_TONE = { out: "text-danger", low: "text-warn", ok: "text-ok" };

/**
 * "<" only while under par, "/" once the minimum is met.
 *
 * The two signs answer different questions. Under par, the stocker needs to see
 * a shortfall, and "<" reads as one. At or over it, there is nothing to fetch,
 * so the slash goes back to reading as stock-against-target — which is the
 * number they use to judge how much more to bring out.
 */
const relation = (qty, threshold) => (qty < threshold ? "<" : "/");

/**
 * The overview row counts products, not pounds.
 *
 * A combined weight across bacon and jerky answers no question anyone on the
 * floor is actually asking. "Five products are below par" does — so the tiles
 * read as a severity ladder, and each one is also the filter that shows you
 * which products it is talking about.
 *
 * "Put out now" deliberately overlaps "Low stock": it is the slice of low that
 * needs no production at all, which makes it the first thing worth doing.
 */
const FOCUS = [
  {
    id: "putOut",
    label: "Put out now",
    icon: ArrowRightCircle,
    tone: "primary",
    hint: "covered from the back",
    match: canPutOut,
  },
  {
    id: "low",
    label: "Low stock",
    icon: AlertTriangle,
    tone: "warn",
    hint: "below par — prep before it's gone",
    match: (i) => stockStatus(i) === "low",
  },
  {
    id: "out",
    label: "Out of stock",
    icon: PackageX,
    tone: "danger",
    hint: "nothing anywhere",
    match: (i) => stockStatus(i) === "out",
  },
  {
    id: "madePile",
    label: "To put away",
    icon: PackageCheck,
    tone: "neutral",
    hint: "made, still not filed",
    match: (i) => stockIn(i, "made") > 0,
  },
];

function SourceBadge({ status, syncedAt, onRefresh }) {
  if (status === "loading") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-ink-3">
        <RefreshCw size={12} className="animate-spin" /> Syncing with Clover…
      </span>
    );
  }
  if (status === "error") {
    return (
      <div className="flex items-center gap-2">
        <Badge tone="warn" icon={CloudOff}>
          Clover unreachable
        </Badge>
        <Button variant="ghost" icon={RefreshCw} onClick={onRefresh}>
          Retry
        </Button>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-2">
      <Badge tone="ok" icon={CheckCircle2}>
        Live from Clover
      </Badge>
      {syncedAt && <span className="text-xs text-ink-4">{relativeTime(syncedAt)}</span>}
      <Button variant="ghost" icon={RefreshCw} onClick={onRefresh}>
        Refresh
      </Button>
    </div>
  );
}

/* --------------------------------------------------------------- Move flow -- */

/**
 * One dialog for every hop — made → freezer, freezer → floor, and the returns
 * that go the other way — because the floor thinks in "move this there", not in
 * three separate transfer screens.
 */
function MoveDialog({ item, initialFrom, onCancel, onConfirm }) {
  const stocked = STOCK_STATES.filter((s) => stockIn(item, s.id) > 0);
  const [from, setFrom] = useState(
    stocked.some((s) => s.id === initialFrom) ? initialFrom : stocked[0]?.id || "made"
  );
  const [to, setTo] = useState(from === "floor" ? "freezer" : from === "made" ? "freezer" : "floor");
  const [amount, setAmount] = useState(stockIn(item, from));

  const available = stockIn(item, from);
  const invalid = amount <= 0 || amount > available;

  const pickFrom = (id) => {
    setFrom(id);
    setAmount(stockIn(item, id));
    if (to === id) setTo(id === "floor" ? "freezer" : "floor");
  };

  return (
    <Modal
      open
      onClose={onCancel}
      title={`Move ${item.product}`}
      icon={ArrowRightCircle}
      footer={
        <>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            variant="success" icon={ArrowRightCircle}
            disabled={invalid}
            onClick={() => onConfirm(item.product, from, to, amount)}
          >
            Move {amount || 0} {item.unit}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field label="From" hint={`${available} ${item.unit} available`}>
          <Segmented
            size="sm" value={from}
            onChange={pickFrom}
            options={STOCK_STATES.map((s) => ({
              value: s.id,
              label: s.short,
              icon: STATE_ICON[s.id],
              disabled: stockIn(item, s.id) <= 0,
            }))}
          />
        </Field>

        <Field
          label="To" hint={
            to === "floor"
              ? "Becomes sellable — Clover's floor count goes up."
              : "Location only. Clover's sellable total doesn't change."
          }
        >
          <Segmented
            size="sm" value={to}
            onChange={setTo}
            options={STOCK_STATES.map((s) => ({
              value: s.id,
              label: s.short,
              icon: STATE_ICON[s.id],
              disabled: s.id === from,
            }))}
          />
        </Field>

        <Field
          label={`Amount (${item.unit})`}
          error={invalid ? `Enter between 1 and ${available}.` : null}
        >
          <div className="flex items-center gap-2">
            <Input
              type="number" size="lg" autoFocus
              value={amount}
              min={0}
              max={available}
              invalid={invalid}
              onChange={(e) => setAmount(Number(e.target.value) || 0)}
              className="tnum flex-1"
            />
            <Button variant="secondary" onClick={() => setAmount(available)} className="shrink-0">
              All
            </Button>
          </div>
        </Field>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------ Product card -- */

/**
 * Everything known about one product, and the few things worth changing.
 *
 * The name is shown but not editable: it is the key that ties this record to
 * Clover's catalogue, to sales velocity, and to any batch that finished into
 * it. Renaming here would quietly orphan all three, so a rename belongs in
 * Clover, where the name actually originates.
 */
function ProductDialog({ item, perDay, canManage, onClose, onSave, onMove, onRemove }) {
  const family = item.type || productType(item.product);
  const [threshold, setThreshold] = useState(String(item.threshold));
  const [max, setMax] = useState(String(item.max));
  const [type, setType] = useState(family);
  const [unit, setUnit] = useState(item.unit);

  const status = stockStatus(item);
  const cover = daysOfCover(item, perDay);
  const potential = potentialCover(item, perDay);
  const short = floorDeficit(item);
  const total = totalStock(item);
  const refill = refillQty(item);
  const nextThreshold = Number(threshold);
  const nextMax = Number(max);

  const minInvalid = !Number.isFinite(nextThreshold) || nextThreshold <= 0;
  // A max at or below the min would make "full" and "too low" the same number.
  const maxInvalid = !Number.isFinite(nextMax) || nextMax <= nextThreshold;
  const invalid = minInvalid || maxInvalid;
  const dirty =
    !invalid &&
    (nextThreshold !== item.threshold ||
      nextMax !== item.max ||
      type !== family ||
      unit !== item.unit);

  return (
    <Modal
      open
      onClose={onClose}
      size="md"
      title={item.product}
      icon={STATE_ICON.floor}
      footer={
        <>
          {canManage && total === 0 && (
            <Button
              variant="ghost"
              icon={Trash2}
              className="mr-auto text-danger"
              onClick={() => onRemove(item.product)}
            >
              Delete
            </Button>
          )}
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
          {canManage && (
            <Button
              variant="primary"
              disabled={!dirty}
              onClick={() =>
                onSave(item.product, {
                  threshold: nextThreshold,
                  max: nextMax,
                  type,
                  unit: unit.trim() || "lb",
                })
              }
            >
              Save changes
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-5">
        <div className="flex items-center gap-2 flex-wrap">
          {status === "out" ? (
            <Badge tone="danger" icon={PackageX}>
              Out of stock
            </Badge>
          ) : status === "low" ? (
            <Badge tone="warn" icon={AlertTriangle}>
              Low stock
            </Badge>
          ) : (
            <Badge tone="ok">In stock</Badge>
          )}
          {canPutOut(item) && (
            <Badge tone="info" icon={ArrowRightCircle}>
              Can be covered from the back
            </Badge>
          )}
          {short > 0 && (
            <span className="text-xs text-ink-3 tnum">
              <span className="text-danger font-medium">
                {short} {item.unit} under the minimum
              </span>
              {refill > 0 && <> · bring {refill} {item.unit} to fill the case</>}
            </span>
          )}
        </div>

        {/* Where the stock physically is, in the order it moves. */}
        <div className="rounded-md border border-line overflow-hidden">
          {STOCK_STATES.map((state) => {
            const Icon = STATE_ICON[state.id];
            const qty = stockIn(item, state.id);
            return (
              <div
                key={state.id}
                className="flex items-center justify-between gap-3 px-3.5 py-2.5 border-b border-line last:border-0"
              >
                <span className="inline-flex items-center gap-2 text-sm text-ink-2">
                  <Icon size={13} className={cx("shrink-0", state.id === "freezer" && "text-cold")} />
                  {state.label}
                  <span className="text-xs text-ink-4">{state.hint}</span>
                </span>
                <span
                  className={cx(
                    "text-sm font-medium tnum",
                    state.id === "floor" ? FLOOR_TONE[status] : qty > 0 ? "text-ink" : "text-ink-4"
                  )}
                >
                  {qty} {item.unit}
                </span>
              </div>
            );
          })}
          <div className="flex items-center justify-between gap-3 px-3.5 py-2.5 bg-sunken">
            <span className="text-sm font-medium text-ink">Total</span>
            <span className="text-sm font-semibold text-ink tnum">
              {total} {item.unit}
            </span>
          </div>
        </div>

        {cover != null ? (
          <div className="flex items-start gap-2.5 px-3.5 py-3 rounded-md bg-canvas border border-line">
            <Timer
              size={15}
              className={cx(
                "shrink-0 mt-px",
                { danger: "text-danger", warn: "text-warn", ok: "text-ok", muted: "text-ink-3" }[
                  coverTone(cover)
                ]
              )}
            />
            <div className="text-xs text-ink-2 leading-relaxed">
              <span className="font-medium">{cover} days</span> of cover on the floor at the last 4
              weeks&rsquo; pace ({perDay} {item.unit}/day)
              {potential != null && potential !== cover && (
                <> · {potential} days once everything behind it is put out</>
              )}
            </div>
          </div>
        ) : (
          <p className="text-xs text-ink-4">
            No sales pace for this product yet, so there is no days-of-cover figure.
          </p>
        )}

        {canManage ? (
          <div className="space-y-4 pt-1 border-t border-line">
            <div className="grid grid-cols-2 gap-3 pt-4">
              <Field
                label={`Minimum (${unit})`}
                error={minInvalid ? "Above zero." : null}
                hint={minInvalid ? null : "Flagged low below this."}
              >
                <Input
                  type="number"
                  value={threshold}
                  invalid={minInvalid}
                  onChange={(e) => setThreshold(e.target.value)}
                  className="tnum"
                />
              </Field>

              <Field
                label={`Full case (${unit})`}
                error={maxInvalid ? "Must exceed the minimum." : null}
                hint={maxInvalid ? null : "What a stocker fills to."}
              >
                <Input
                  type="number"
                  value={max}
                  invalid={maxInvalid}
                  onChange={(e) => setMax(e.target.value)}
                  className="tnum"
                />
              </Field>
            </div>

            <Field label="Family" hint="Guessed from the name — correct it if the guess is wrong.">
              <Segmented
                size="sm"
                scroll
                value={type}
                onChange={setType}
                options={PRODUCT_TYPES.map((t) => ({ value: t, label: t }))}
              />
            </Field>

            <Field label="Unit" hint="Whatever this product is counted in.">
              <Input value={unit} onChange={(e) => setUnit(e.target.value)} className="max-w-24" />
            </Field>
          </div>
        ) : (
          <p className="text-xs text-ink-4 border-t border-line pt-4">
            Minimum {item.threshold} {item.unit} · full case {item.max} {item.unit} · {family}. Ask a
            manager to change these.
          </p>
        )}

        {total > 0 && (
          <Button
            block
            variant="secondary"
            icon={ArrowRightCircle}
            onClick={() => onMove(item)}
          >
            Move stock
          </Button>
        )}
      </div>
    </Modal>
  );
}

function AddProductDialog({ existing, unit, onCancel, onAdd }) {
  const [name, setName] = useState("");
  const [threshold, setThreshold] = useState("");
  const [touched, setTouched] = useState(false);
  const duplicate = existing.some((p) => p.toLowerCase() === name.trim().toLowerCase());
  const valid = name.trim().length > 0 && !duplicate;
  const type = productType(name);

  // Follows the family as you type, until you disagree with it once.
  const suggested = defaultThreshold(name);
  const effective = touched && threshold !== "" ? Number(threshold) : suggested;

  return (
    <Modal
      open
      onClose={onCancel}
      title="Add a product" icon={Plus}
      footer={
        <>
          <Button variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
          <Button
            variant="primary" icon={Plus}
            disabled={!valid}
            onClick={() =>
              onAdd({
                product: name.trim(),
                type,
                made: 0,
                freezer: 0,
                floor: 0,
                threshold: effective || suggested,
                max: capacityFor(effective || suggested),
                unit,
              })
            }
          >
            Add product
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field
          label="Product name" error={duplicate ? "That product already exists." : null}
          hint={duplicate ? null : "Appears on the schedule and the production board."}
        >
          <Input
            autoFocus
            value={name}
            invalid={duplicate}
            placeholder="e.g. Bratwurst - Cheddar Ranch" onChange={(e) => setName(e.target.value)}
          />
        </Field>

        {name.trim() && (
          <p className="text-xs text-ink-3">
            Filed under <span className="font-medium text-ink-2">{type}</span> — from the name.
          </p>
        )}

        <Field
          label={`Low-stock threshold (${unit})`}
          hint={`Flags the product once floor stock drops below this. ${DEFAULT_THRESHOLD} is the house minimum.`}
        >
          <Input
            type="number" value={threshold}
            placeholder={String(DEFAULT_THRESHOLD)}
            onChange={(e) => setThreshold(e.target.value)}
            className="tnum"
          />
        </Field>
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------------- Screen -- */

const EMPTY_FILTERS = { type: "all", state: "all", min: "", max: "", focus: null, tightCover: false };

export default function InventoryScreen({
  inventory,
  velocity = {},
  status,
  syncedAt,
  canManage,
  onRefresh,
  onMove,
  onAddProduct,
  onUpdateProduct,
  onRemoveProduct,
}) {
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [showFilters, setShowFilters] = useState(false);
  const [moving, setMoving] = useState(null);
  const [detail, setDetail] = useState(null);
  const [adding, setAdding] = useState(false);

  const unit = inventory[0]?.unit || "lb";
  const set = (patch) => setFilters((f) => ({ ...f, ...patch }));

  const rate = (item) => velocity[item.product];

  const counts = useMemo(
    () =>
      Object.fromEntries(
        FOCUS.map((f) => [f.id, inventory.filter(f.match).length])
      ),
    [inventory]
  );

  /** The single product closest to running dry — the headline cover figure. */
  const tightest = useMemo(() => {
    let worst = null;
    for (const item of inventory) {
      const days = daysOfCover(item, velocity[item.product]);
      if (days == null) continue;
      if (!worst || days < worst.days) worst = { item, days };
    }
    return worst;
  }, [inventory, velocity]);

  const hasVelocity = Object.keys(velocity).length > 0;

  const activeFocus = FOCUS.find((f) => f.id === filters.focus) || null;

  // Held by name, not by object: the row it came from is replaced on every
  // edit, and a captured copy would keep showing stale counts.
  const detailItem = detail ? inventory.find((i) => i.product === detail) : null;

  /** Products needing attention, by family — i.e. which station to staff. */
  const families = useMemo(() => {
    const tally = {};
    for (const item of inventory) {
      const family = item.type || productType(item.product);
      const status = stockStatus(item);
      tally[family] = tally[family] || { total: 0, need: 0 };
      tally[family].total += 1;
      if (status !== "ok") tally[family].need += 1;
    }
    return PRODUCT_TYPES.filter((t) => tally[t]).map((t) => ({ type: t, ...tally[t] }));
  }, [inventory]);

  /** Types actually present, so the filter never offers an empty bucket. */
  const types = useMemo(() => {
    const present = new Set(inventory.map((i) => i.type || productType(i.product)));
    return PRODUCT_TYPES.filter((t) => present.has(t));
  }, [inventory]);

  /** The number the weight filter compares against follows the state filter. */
  const measure = (item) =>
    filters.state === "all" ? totalStock(item) : stockIn(item, filters.state);

  const visible = useMemo(() => {
    const min = filters.min === "" ? null : Number(filters.min);
    const max = filters.max === "" ? null : Number(filters.max);

    return inventory.filter((item) => {
      if (!item.product.toLowerCase().includes(query.toLowerCase())) return false;
      if (filters.type !== "all" && (item.type || productType(item.product)) !== filters.type)
        return false;
      if (filters.state !== "all" && stockIn(item, filters.state) <= 0) return false;

      if (filters.focus) {
        const focus = FOCUS.find((f) => f.id === filters.focus);
        if (focus && !focus.match(item)) return false;
      }

      if (filters.tightCover) {
        const days = daysOfCover(item, velocity[item.product]);
        if (days == null || days >= COVER_WARN_DAYS) return false;
      }

      const weight = measure(item);
      if (min != null && weight < min) return false;
      if (max != null && weight > max) return false;
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inventory, query, filters, velocity]);

  const activeCount =
    (filters.type !== "all" ? 1 : 0) +
    (filters.state !== "all" ? 1 : 0) +
    (filters.min !== "" || filters.max !== "" ? 1 : 0) +
    (filters.focus ? 1 : 0) +
    (filters.tightCover ? 1 : 0);

  const clearAll = () => {
    setQuery("");
    setFilters(EMPTY_FILTERS);
  };

  return (
    <div className="space-y-5">
      <StatGrid>
        {FOCUS.map((f) => (
          <StatCard
            key={f.id}
            icon={f.icon}
            label={f.label}
            value={counts[f.id]}
            tone={counts[f.id] ? f.tone : "neutral"}
            hint={
              f.id === "putOut" && counts.low
                ? `${counts.putOut} of the ${counts.low} low`
                : f.hint
            }
            active={filters.focus === f.id}
            onClick={() => set({ focus: filters.focus === f.id ? null : f.id })}
          />
        ))}
      </StatGrid>

      {/* Quiet enough to ignore once you know, present enough to find the
          first time — and it earns its line by doubling as the way out of an
          active filter, so it is never purely decorative. */}
      <div className="-mt-2 flex items-center justify-between gap-3 px-0.5 text-xs">
        {activeFocus ? (
          <>
            <span className="text-ink-3 truncate">
              Showing <span className="font-medium text-ink-2">{activeFocus.label.toLowerCase()}</span>
              {" "}&middot; {visible.length} of {inventory.length}
            </span>
            <button
              type="button" onClick={() => set({ focus: null })}
              className="shrink-0 font-medium text-ink-2 hover:text-ink hover:underline"
            >
              Clear
            </button>
          </>
        ) : (
          <span className="text-ink-3">Each count filters the list.</span>
        )}
      </div>

      {/* Which station to staff, rather than one number for all of them. */}
      {families.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar -mx-1 px-1">
          <span className="text-xs font-medium text-ink-4 shrink-0">
            Needs work
          </span>
          {families.map((f) => {
            const on = filters.type === f.type;
            return (
              <button
                key={f.type}
                type="button" aria-pressed={on}
                onClick={() => set({ type: on ? "all" : f.type })}
                className={cx(
                  "shrink-0 inline-flex items-center gap-1.5 pl-2.5 pr-2 h-[var(--ctl-h)] rounded-full border",
                  "text-xs font-medium transition-colors duration-100",
                  on
                    ? "border-line-strong bg-hover text-ink"
                    : "border-line bg-surface text-ink-2 hover:bg-sunken"
                )}
              >
                {f.type}
                <span
                  className={cx(
                    "tnum text-xs px-1.5 rounded-full",
                    f.need ? "bg-danger-soft text-danger" : "bg-sunken text-ink-4"
                  )}
                >
                  {f.need}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Cover is the only figure that answers "will I run out", so it leads. */}
      {tightest && (
        <button
          type="button" onClick={() => set({ tightCover: !filters.tightCover })}
          aria-pressed={filters.tightCover}
          className={cx(
            "w-full flex items-center gap-3 px-4 py-3 rounded-md border text-left",
            "transition-colors duration-100",
            filters.tightCover
              ? "border-line-strong bg-hover"
              : "border-line bg-surface hover:bg-sunken"
          )}
        >
          <Timer
            size={16}
            className={cx(
              "shrink-0",
              {
                danger: "text-danger",
                warn: "text-warn",
                ok: "text-ok",
                muted: "text-ink-3",
              }[coverTone(tightest.days)]
            )}
          />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-ink truncate">
              <span className="font-medium">{tightest.item.product}</span> runs out first
            </p>
            <p className="text-xs text-ink-3">
              {tightest.days} days on the floor at the last 4 weeks&rsquo; pace
              {potentialCover(tightest.item, velocity[tightest.item.product]) != null && (
                <> · {potentialCover(tightest.item, velocity[tightest.item.product])}d if you put everything out</>
              )}
            </p>
          </div>
          <span className="shrink-0 text-xs font-medium text-ink-3">
            {filters.tightCover ? "Showing" : `Under ${COVER_WARN_DAYS}d`}
          </span>
        </button>
      )}

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <SourceBadge status={status} syncedAt={syncedAt} onRefresh={onRefresh} />
        {canManage && (
          <Button variant="primary" icon={Plus} onClick={() => setAdding(true)}>
            Add product
          </Button>
        )}
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <SearchInput value={query} onChange={setQuery} placeholder="Search products…" className="flex-1" />
          <Button
            variant={showFilters || activeCount ? "primary" : "secondary"}
            icon={SlidersHorizontal}
            onClick={() => setShowFilters((v) => !v)}
            className="shrink-0"
          >
            <span className="hidden sm:inline">Filters</span>
            {activeCount > 0 && (
              <span className="ml-0.5 tnum text-xs px-1.5 rounded-full bg-white/25">
                {activeCount}
              </span>
            )}
          </Button>
        </div>

        {showFilters && (
          <Card inset className="space-y-4">
            <Field label="Product" hint="Families are read from the product name.">
              <Segmented
                size="sm" scroll
                value={filters.type}
                onChange={(v) => set({ type: v })}
                options={[
                  { value: "all", label: "All" },
                  ...types.map((t) => ({ value: t, label: t })),
                ]}
              />
            </Field>

            <Field label="Has stock in" hint="Also picks which count the weight filter reads.">
              <Segmented
                size="sm" scroll
                value={filters.state}
                onChange={(v) => set({ state: v })}
                options={[
                  { value: "all", label: "Anywhere" },
                  ...STOCK_STATES.map((s) => ({
                    value: s.id,
                    label: s.short,
                    icon: STATE_ICON[s.id],
                  })),
                ]}
              />
            </Field>

            <Field
              label={`Weight (${unit})`}
              hint={
                filters.state === "all"
                  ? "Against the combined count across all three states."
                  : `Against the ${stateLabel(filters.state).toLowerCase()} count.`
              }
            >
              <div className="flex items-center gap-2">
                <Input
                  type="number" value={filters.min}
                  placeholder="Min" onChange={(e) => set({ min: e.target.value })}
                  className="tnum"
                />
                <ArrowRight size={14} className="text-ink-4 shrink-0" />
                <Input
                  type="number" value={filters.max}
                  placeholder="Max" onChange={(e) => set({ max: e.target.value })}
                  className="tnum"
                />
              </div>
            </Field>

            <div className="flex items-center justify-between gap-3 flex-wrap">
              <Button
                size="sm" variant={filters.tightCover ? "primary" : "secondary"}
                icon={Timer}
                disabled={!hasVelocity}
                onClick={() => set({ tightCover: !filters.tightCover })}
              >
                Under {COVER_WARN_DAYS} days of cover
              </Button>
              {(activeCount > 0 || query) && (
                <Button size="sm" variant="ghost" icon={X} onClick={clearAll}>
                  Clear all
                </Button>
              )}
            </div>
          </Card>
        )}
      </div>

      {status === "loading" ? (
        <SkeletonRows rows={4} />
      ) : visible.length === 0 ? (
        <Card>
          <EmptyState
            icon={Package}
            title={query || activeCount ? "No matching products" : "No products yet"}
            description={
              query || activeCount
                ? "Try a wider weight range, another family, or clear the filters."
                : "Products sync in from Clover, or add one by hand."
            }
            action={
              query || activeCount ? <Button onClick={clearAll}>Clear filters</Button> : null
            }
          />
        </Card>
      ) : (
        <div>
          <div className="py-2 border-b border-line text-xs font-medium text-ink-3">
            {visible.length} of {inventory.length} products
          </div>
          <ul className="divide-y divide-line border-b border-line">
            {visible.map((item) => {
              const status = stockStatus(item);
              const low = status !== "ok";
              const back = behindStock(item);
              const floor = stockIn(item, "floor");
              const made = stockIn(item, "made");
              const movable = canPutOut(item);
              const refill = refillQty(item);
              const cover = daysOfCover(item, rate(item));
              const hasStock = totalStock(item) > 0;
              return (
                <li
                  key={item.product}
                  className="flex items-center justify-between gap-4 py-2.5 px-1 -mx-1 rounded-md hover:bg-faint transition-colors"
                >
                  {/* The whole content area is the trigger, so the tap target
                      matches what the row looks like; the Move button stays a
                      sibling rather than a nested control. */}
                  <button
                    type="button"
                    onClick={() => setDetail(item.product)}
                    className="min-w-0 text-left flex-1 rounded-md"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <p className="text-sm font-medium text-ink truncate">{item.product}</p>
                      <span className="shrink-0 text-xs font-medium text-ink-4">
                        {item.type || productType(item.product)}
                      </span>
                    </div>

                    <div className="mt-1 flex items-center flex-wrap gap-x-3 gap-y-1 text-xs tnum">
                      {/* The floor is the only count that is actually sellable,
                          so it leads and everything else is "behind" it.

                          Stock and par read as one fraction rather than as
                          three chips: "0 lb on floor", "min 25" and "25 lb
                          short" were three spellings of a single fact, and on a
                          catalogue sitting at zero every row said all three. */}
                      <span
                        title={
                          low
                            ? `On the floor, against the ${item.threshold} ${item.unit} minimum`
                            : `On the floor, against a full case of ${item.max} ${item.unit}`
                        }
                        className="inline-flex items-center gap-1 text-ink-3"
                      >
                        <Store size={11} />
                        {/* Only the stock figure carries the alarm. Colouring
                            the target too made the minimum itself look like the
                            problem, when it is the thing being measured against. */}
                        <span className={cx("font-medium", FLOOR_TONE[status])}>{floor}</span>
                        {/* A relational operator rather than a slash: "0 / 45"
                            read as a capacity, as though 45 were a ceiling. The
                            comparison says which side of the minimum you are on,
                            and stays true when stock is over it. */}
                        <span className="text-ink-4">{relation(floor, item.threshold)}</span>
                        {/* Each sign gets the benchmark it implies: short of
                            par, the minimum is what you are short OF; at or
                            above it, the slash reads against how full the case
                            should be. */}
                        {low ? item.threshold : item.max} {item.unit} on floor
                      </span>

                      {/* Not the shortfall against the minimum — the amount
                          that actually fills the case. Topping up to the
                          minimum would trip the same alert on the next sale. */}
                      {low && refill > 0 && (
                        <span className="text-warn font-medium">bring {refill}</span>
                      )}
                      {cover != null && (
                        <span
                          className={cx(
                            "inline-flex items-center gap-1",
                            {
                              danger: "text-danger",
                              warn: "text-warn",
                              ok: "text-ink-3",
                              muted: "text-ink-4",
                            }[coverTone(cover)]
                          )}
                        >
                          <Timer size={11} /> {cover}d cover
                        </span>
                      )}

                      {/* Made and freezer differ only in whether someone has
                          put the stock away — neither is sellable — so they
                          read as one number, and only split when the made pile
                          is non-empty and that put-away work actually exists. */}
                      <span
                        className={cx(
                          "inline-flex items-center gap-1",
                          back > 0 ? "text-ink-3" : "text-ink-4"
                        )}
                        title="Held back: made plus freezer. Neither is sellable until it is out front."
                      >
                        <Snowflake size={11} className={back > 0 ? "text-cold" : undefined} />
                        {back} {item.unit} back
                        {made > 0 && (
                          <span className="text-ink-4">
                            ({made} not put away)
                          </span>
                        )}
                      </span>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 shrink-0">
                    {status === "out" ? (
                      <Badge tone="danger" icon={PackageX}>
                        Out
                      </Badge>
                    ) : status === "low" ? (
                      <Badge tone="warn" icon={AlertTriangle}>
                        Low
                      </Badge>
                    ) : (
                      <Badge tone="ok">In stock</Badge>
                    )}
                    {hasStock && (
                      <Button
                        size="sm" variant={movable ? "secondary" : "ghost"}
                        iconRight={ArrowRightCircle}
                        onClick={() => setMoving({ item, from: stockIn(item, "made") > 0 ? "made" : "freezer" })}
                      >
                        Move
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {detailItem && (
        <ProductDialog
          item={detailItem}
          perDay={rate(detailItem)}
          canManage={canManage}
          onClose={() => setDetail(null)}
          onSave={(product, patch) => {
            onUpdateProduct(product, patch);
            setDetail(null);
          }}
          onRemove={(product) => {
            onRemoveProduct(product);
            setDetail(null);
          }}
          onMove={(item) => {
            setDetail(null);
            setMoving({ item, from: stockIn(item, "made") > 0 ? "made" : "freezer" });
          }}
        />
      )}

      {moving && (
        <MoveDialog
          item={moving.item}
          initialFrom={moving.from}
          onCancel={() => setMoving(null)}
          onConfirm={(product, from, to, amount) => {
            onMove(product, from, to, amount);
            setMoving(null);
          }}
        />
      )}

      {adding && (
        <AddProductDialog
          existing={inventory.map((i) => i.product)}
          unit={unit}
          onCancel={() => setAdding(false)}
          onAdd={(item) => {
            onAddProduct(item);
            setAdding(false);
          }}
        />
      )}
    </div>
  );
}
