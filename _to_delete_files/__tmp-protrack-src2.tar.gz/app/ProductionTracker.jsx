"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  History,
  LayoutGrid,
  ListTodo,
  LogOut,
  Package,
  Users,
} from "lucide-react";

import { Badge, SlotProvider, SlotTarget, ToastProvider, cx, useToast } from "./components/ui";
import RoleSwitcher from "./components/RoleSwitcher";
import SignInScreen from "./screens/SignInScreen";
import BoardScreen from "./screens/BoardScreen";
import TodoScreen from "./screens/TodoScreen";
import ScheduleScreen from "./screens/ScheduleScreen";
import InventoryScreen from "./screens/InventoryScreen";
import InsightsScreen from "./screens/InsightsScreen";
import TeamScreen from "./screens/TeamScreen";
import { usePersistentState, useSession } from "./lib/store";
import { StaffProvider } from "./lib/staff";
import {
  DEFAULT_TASK_CATEGORIES,
  SEED,
  STAGES,
  STATIONS,
  categoryInUse,
  defaultThreshold,
  isManager,
  moveStock,
  newId,
  nextStageIndex,
  normalizeItem,
  productType,
  stateLabel,
  todayKey,
  yieldPct,
} from "./lib/domain";

const NAV = [
  { id: "board", label: "Production board", short: "Board", icon: LayoutGrid },
  { id: "todo", label: "To-Do", short: "To-Do", icon: ListTodo },
  { id: "schedule", label: "Schedule", short: "Schedule", icon: CalendarDays, managerOnly: true },
  { id: "inventory", label: "Inventory", short: "Inventory", icon: Package },
  { id: "insights", label: "Insights", short: "Insights", icon: History, managerOnly: true },
  { id: "team", label: "Team & PINs", short: "Team", icon: Users },
];

/** Static class names so Tailwind can see every column count it may render. */
const TAB_COLS = {
  3: "grid-cols-3",
  4: "grid-cols-4",
  5: "grid-cols-5",
  6: "grid-cols-6",
};

/* --------------------------------------------------------------- App shell */

function Shell({ user, nav, view, onNavigate, onSignOut, onViewAsRole, children }) {
  const active = nav.find((n) => n.id === view) || nav[0];

  return (
    <div className="min-h-screen bg-canvas">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:fixed lg:inset-y-0 lg:left-0 lg:w-[18.75%] lg:min-w-[240px] lg:max-w-[300px] lg:z-20 bg-sunken">
        <div className="px-3 py-3">
          <p className="text-xs font-medium text-brand">
            Milaca Meats
          </p>
          <p className="mt-1 text-sm font-medium text-ink">Production</p>
        </div>

        <nav className="flex-1 px-2 space-y-px overflow-y-auto thin-scrollbar">
          {nav.map((n) => {
            const on = n.id === view;
            return (
              <button
                key={n.id}
                onClick={() => onNavigate(n.id)}
                aria-current={on ? "page" : undefined}
                className={cx(
                  "w-full flex items-center gap-2 px-2 rounded-md text-sm",
                  "min-h-[var(--row-h)] transition-colors duration-100",
                  // Selection is the same 5% tint as hover. Accent is not spent on navigation.
                  on ? "bg-hover text-ink font-medium" : "text-ink-2 hover:bg-hover hover:text-ink"
                )}
              >
                <n.icon size={16} className={cx("shrink-0", on ? "text-icon" : "text-icon-2")} />
                <span className="truncate">{n.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-2">
          <div className="flex items-center gap-2.5 px-2 py-2">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-ink text-white text-xs font-medium shrink-0">
              {user.initials}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-ink truncate leading-tight">{user.name}</p>
              <p className="text-xs text-ink-3 capitalize truncate">
                {isManager(user) ? user.role : user.station || "Crew"}
              </p>
            </div>
            <button
              onClick={onSignOut}
              aria-label="Sign out" title="Sign out" className="w-[var(--ctl-h)] h-[var(--ctl-h)] flex items-center justify-center rounded-md text-icon-2 hover:text-danger hover:bg-hover transition-colors"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="lg:hidden sticky top-0 z-30 bg-canvas border-b border-line pt-safe">
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <p className="text-xs font-medium text-brand leading-none mb-1.5">
              Milaca Meats
            </p>
            <h1 className="text-base font-medium text-ink leading-none truncate">
              {active.label}
            </h1>
          </div>
          <button
            onClick={onSignOut}
            className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-full bg-surface border border-line shrink-0"
          >
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-ink text-white text-xs font-medium">
              {user.initials}
            </span>
            <LogOut size={13} className="text-ink-3" />
          </button>
        </div>
      </header>

      <main className="lg:[padding-left:max(18.75%,240px)]">
        <div className="mx-auto w-full max-w-5xl px-4 pt-5 pb-28 sm:px-6 lg:px-10 lg:pt-8 lg:pb-14">
          {/* The page header carries the page's OWN actions and a one-line
              subtitle, so a screen never has to stack them into its content
              where they read as one more filter. Phones already get the view
              name from the sticky bar, so only actions and subtitle show. */}
          <div className="mb-5">
            <div className="flex items-start justify-between gap-4">
              <h2 className="hidden lg:block text-[32px] font-bold text-ink leading-tight">
                {active.label}
              </h2>
              <div className="flex items-center gap-2 ml-auto shrink-0">
                {isManager(user) && (
                  <Badge className="hidden lg:inline-flex">
                    {user.role === "owner" ? "Owner" : "Manager"}
                  </Badge>
                )}
                <SlotTarget name="page-actions" className="flex items-center gap-2" />
              </div>
            </div>
            <SlotTarget
              name="page-subtitle"
              className="empty:hidden mt-1.5 text-sm text-ink-2 leading-normal"
            />
          </div>
          {children}
        </div>
      </main>

      <RoleSwitcher user={user} onChange={onViewAsRole} />

      {/* Mobile tab bar */}
      <nav className="lg:hidden fixed inset-x-0 bottom-0 z-30 bg-surface border-t border-line pb-safe">
        <div className={cx("grid", TAB_COLS[nav.length] || "grid-cols-4")}>
          {nav.map((n) => {
            const on = n.id === view;
            return (
              <button
                key={n.id}
                onClick={() => onNavigate(n.id)}
                aria-current={on ? "page" : undefined}
                className={cx(
                  "flex flex-col items-center justify-center gap-1 min-h-14 px-1 py-2",
                  "text-xs font-medium transition-colors duration-100",
                  on ? "text-ink" : "text-ink-3"
                )}
              >
                <n.icon size={19} className="shrink-0" />
                <span className="truncate max-w-full">{n.short}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

/* ------------------------------------------------------------- Application */

function Application() {
  const toast = useToast();
  const { user, signIn, signOut } = useSession();
  const today = todayKey();

  const [view, setView] = useState("board");
  const [batches, setBatches] = usePersistentState("batches", SEED.batches);
  const [history, setHistory] = usePersistentState("history", SEED.history);
  const [inventory, setInventory] = usePersistentState("inventory", SEED.inventory);
  const [schedule, setSchedule] = usePersistentState("schedule", SEED.schedule);
  const [todos, setTodos] = usePersistentState("todos", SEED.todos);
  const [taskCategories, setTaskCategories] = usePersistentState("taskCategories", DEFAULT_TASK_CATEGORIES);

  /** Records saved before the third state existed get filled in on read. */
  const stock = useMemo(() => inventory.map(normalizeItem), [inventory]);

  const [cloverStatus, setCloverStatus] = useState("loading");
  const [syncedAt, setSyncedAt] = useState(null);
  const [velocity, setVelocity] = useState({});

  /* ---- Clover ---- */

  const loadClover = useCallback(async () => {
    setCloverStatus("loading");
    try {
      const res = await fetch("/api/inventory");
      const data = await res.json();
      const items = (data.items || []).filter((i) => !i.hidden);
      // An empty result is a legitimate Clover state (e.g. every product was
      // deleted) and should render the empty state, not "Clover unreachable".
      if (data.error) throw new Error(data.error);

      // Clover lets two separate items share one display name (a duplicate
      // entry, or two SKUs nobody renamed apart). Every other part of this
      // app treats the name as the product's identity, so collapse
      // same-named items into a single row here, summing their sellable
      // stock, instead of letting the duplicate name reach the list below.
      const stockByName = new Map();
      for (const item of items) {
        stockByName.set(item.name, (stockByName.get(item.name) ?? 0) + (item.stockCount ?? 0));
      }

      setInventory((prev) =>
        Array.from(stockByName.entries()).map(([name, stock]) => {
          // Clover only knows what is sellable. The made / freezer / floor split
          // lives here, so an existing local split survives every refresh.
          const existing = prev.find((p) => p.product === name);
          return normalizeItem({
            product: name,
            type: existing?.type ?? productType(name),
            made: existing?.made ?? 0,
            freezer: existing?.freezer ?? 0,
            floor: existing ? existing.floor : stock,
            threshold: existing?.threshold ?? defaultThreshold(name),
            unit: existing?.unit ?? "lb",
          });
        })
      );
      setCloverStatus("live");
      setSyncedAt(new Date().toISOString());
    } catch {
      setCloverStatus("error");
    }

    // Days-of-cover is a bonus signal — a merchant with no order history simply
    // doesn't get one, and the screen carries on without it.
    try {
      const res = await fetch("/api/sales?days=28");
      const data = await res.json();
      setVelocity(data.perDay || {});
    } catch {
      setVelocity({});
    }
  }, [setInventory]);

  useEffect(() => {
    loadClover();
  }, [loadClover]);

  /* ---- Inventory ---- */

  /**
   * Upsert, not update: a batch can finish for a product Clover hasn't seen yet
   * (a new recipe, a first run). Dropping that weight on the floor would be a
   * silent inventory loss, so the product is created instead.
   */
  const addStock = (product, amount, state) => {
    setInventory((prev) => {
      const known = prev.some((i) => i.product === product);
      if (!known) {
        return [
          ...prev,
          normalizeItem({
            product,
            made: 0,
            freezer: 0,
            floor: 0,
            [state]: amount,
            threshold: defaultThreshold(product),
            unit: prev[0]?.unit ?? "lb",
          }),
        ];
      }
      return prev.map((i) => {
        if (i.product !== product) return i;
        const item = normalizeItem(i);
        return { ...item, [state]: +(item[state] + amount).toFixed(1) };
      });
    });
  };

  const handleMove = (product, from, to, amount) => {
    setInventory((prev) =>
      prev.map((i) => (i.product === product ? moveStock(normalizeItem(i), from, to, amount) : i))
    );
    toast(`Moved ${amount} ${product}`, {
      detail:
        to === "floor"
          ? `${stateLabel(from)} → on floor. Now sellable in Clover.`
          : `${stateLabel(from)} → ${stateLabel(to).toLowerCase()}. Clover's floor count is unchanged.`,
    });
  };

  const handleUpdateProduct = (product, patch) => {
    setInventory((prev) =>
      prev.map((i) => (i.product === product ? { ...normalizeItem(i), ...patch } : i))
    );
    toast(`${product} updated`, {
      detail: `${patch.threshold}–${patch.max} ${patch.unit} · ${patch.type}`,
    });
  };

  const handleRemoveProduct = (product) => {
    setInventory((prev) => prev.filter((i) => i.product !== product));
    toast(`${product} removed`, {
      detail: "It will come back on the next sync if Clover still lists it.",
    });
  };

  const handleAddProduct = (item) => {
    setInventory((prev) => [...prev, normalizeItem(item)]);
    toast(`${item.product} added`, { detail: "Starts at zero in all three states." });
  };

  /* ---- Board ---- */

  const handleAdvance = (id, staff) => {
    setBatches((prev) =>
      prev.map((b) => (b.id === id ? { ...b, stage: nextStageIndex(b), lastActionBy: staff.name } : b))
    );
    toast("Batch moved forward");
  };

  const handleWeighIn = (id, boxWeight, staff) => {
    setBatches((prev) =>
      prev.map((b) =>
        b.id === id ? { ...b, boxWeight, stage: nextStageIndex(b), lastActionBy: staff.name } : b
      )
    );
    toast(`Box weight recorded — ${boxWeight} lb`, { detail: `Confirmed by ${staff.name}` });
  };

  const handleFinalize = (id, finalWeight, destination, staff) => {
    const batch = batches.find((b) => b.id === id);
    if (!batch) return;

    setBatches((prev) =>
      prev.map((b) =>
        b.id === id
          ? {
              ...b,
              finalWeight,
              stage: STAGES.length - 1,
              destination,
              lastActionBy: staff.name,
            }
          : b
      )
    );

    setHistory((prev) => [
      {
        id: batch.id,
        product: batch.product,
        closedOn: today,
        closedBy: staff.name,
        boxWeight: batch.boxWeight || batch.estWeight,
        finalWeight,
        minutes: null,
      },
      ...prev,
    ]);

    addStock(batch.product, finalWeight, destination);

    const where =
      destination === "floor" ? "retail floor" : destination === "freezer" ? "freezer" : "made pile";
    const pct = yieldPct(batch.boxWeight || batch.estWeight, finalWeight);
    toast(destination === "floor" ? `${finalWeight} lb synced to Clover` : `${finalWeight} lb recorded`, {
      detail: `${batch.product} → ${where}${pct != null ? ` · ${pct}% yield` : ""}`,
    });
  };

  /* ---- To-Do ---- */

  const handleAddTodo = (task, staff) => {
    setTodos((prev) => [
      {
        id: newId("TD"),
        completed: false,
        createdBy: staff.name,
        createdAt: new Date().toISOString(),
        ...task,
      },
      ...prev,
    ]);
    toast(`"${task.title}" added to the list`, {
      detail: task.assignedTo ? "Assigned to one person." : "Open to anyone on shift.",
    });
  };

  const handleToggleTodo = (id, staff) => {
    setTodos((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const completed = !t.completed;
        return {
          ...t,
          completed,
          completedBy: completed ? staff.name : null,
          completedAt: completed ? new Date().toISOString() : null,
        };
      })
    );
  };

  const handleRemoveTodo = (id) => {
    setTodos((prev) => prev.filter((t) => t.id !== id));
  };

  const handleAddTaskCategory = ({ label, iconId }) => {
    setTaskCategories((prev) => [...prev, { id: newId("CAT"), label, iconId }]);
    toast(`"${label}" added as a category`);
  };

  const handleRenameTaskCategory = (id, label) => {
    setTaskCategories((prev) => prev.map((c) => (c.id === id ? { ...c, label } : c)));
  };

  const handleRemoveTaskCategory = (id) => {
    const category = taskCategories.find((c) => c.id === id);
    if (categoryInUse(todos, id)) {
      toast(`Can't remove "${category?.label}"`, {
        tone: "error",
        detail: "Recategorize its tasks first.",
      });
      return;
    }
    setTaskCategories((prev) => prev.filter((c) => c.id !== id));
    toast(`"${category?.label}" removed`);
  };

  /* ---- Schedule ---- */

  const handleAddTask = (day, station, product, qty) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        [station]: [...((prev[day] && prev[day][station]) || []), { id: newId("T"), text: product, qty, unit: "lb" }],
      },
    }));

    // Today's plan becomes real work immediately; a future day stays a plan.
    if (day === today) {
      setBatches((prev) => [
        ...prev,
        {
          id: newId("B"),
          product,
          estWeight: qty,
          boxWeight: null,
          stage: STATIONS.indexOf(station),
          needsSmoke: station === "Smokehouse",
          destination: null,
          startedAt: today,
        },
      ]);
      toast(`${product} added to ${station}`, { detail: "Batch card created for today." });
    } else {
      toast(`${product} planned`, { detail: `${station} · ${qty} lb` });
    }
  };

  const handleRemoveTask = (day, station, id) => {
    setSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        [station]: ((prev[day] && prev[day][station]) || []).filter((t) => t.id !== id),
      },
    }));
  };

  /* ---- Render ---- */

  if (!user) return <SignInScreen onSignIn={signIn} />;

  const nav = NAV.filter((n) => isManager(user) || !n.managerOnly);
  const current = nav.some((n) => n.id === view) ? view : "board";

  return (
    <Shell
      user={user}
      nav={nav}
      view={current}
      onNavigate={setView}
      onSignOut={signOut}
      onViewAsRole={(role) => {
        // Re-signs the same person at a different role: session only, so the
        // stored roster keeps whatever they actually hold.
        signIn({ ...user, role });
        toast(`Viewing as ${role}`, { tone: "info" });
      }}
    >
      {current === "board" && (
        <BoardScreen
          batches={batches}
          schedule={schedule}
          today={today}
          user={user}
          onAdvance={handleAdvance}
          onWeighIn={handleWeighIn}
          onFinalize={handleFinalize}
          onCompleteTask={(station, id) => handleRemoveTask(today, station, id)}
        />
      )}

      {current === "todo" && (
        <TodoScreen
          todos={todos}
          categories={taskCategories}
          user={user}
          onAdd={handleAddTodo}
          onToggle={(id) => handleToggleTodo(id, user)}
          onRemove={handleRemoveTodo}
          onAddCategory={handleAddTaskCategory}
          onRenameCategory={handleRenameTaskCategory}
          onRemoveCategory={handleRemoveTaskCategory}
        />
      )}

      {current === "schedule" && (
        <ScheduleScreen
          schedule={schedule}
          inventory={stock}
          today={today}
          onAdd={handleAddTask}
          onRemove={handleRemoveTask}
        />
      )}

      {current === "inventory" && (
        <InventoryScreen
          inventory={stock}
          velocity={velocity}
          status={cloverStatus}
          syncedAt={syncedAt}
          canManage={isManager(user)}
          onRefresh={loadClover}
          onMove={handleMove}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onRemoveProduct={handleRemoveProduct}
        />
      )}

      {current === "insights" && <InsightsScreen history={history} />}

      {current === "team" && (
        <TeamScreen
          user={user}
          onNotify={(message, tone = "success") => toast(message, { tone })}
        />
      )}
    </Shell>
  );
}

export default function ProductionTracker() {
  return (
    <ToastProvider>
      <SlotProvider>
        <StaffProvider>
          <Application />
        </StaffProvider>
      </SlotProvider>
    </ToastProvider>
  );
}
