"use client";

import React, { useState } from "react";
import { AlertTriangle, ArrowRightCircle, PackageX, Timer, Trash2 } from "lucide-react";

import { Badge, Button, Field, Input, Modal, Segmented, cx } from "./ui";
import {
  PRODUCT_TYPES,
  STATE_ICON,
  STOCK_STATES,
  canPutOut,
  coverTone,
  daysOfCover,
  floorDeficit,
  potentialCover,
  productType,
  refillQty,
  stockIn,
  stockStatus,
  totalStock,
} from "../lib/domain";

/** Traffic light on the floor count: nothing / below par / at or over par. */
const FLOOR_TONE = { out: "text-danger", low: "text-warn", ok: "text-ok" };

/**
 * Everything known about one inventory item, and the few things worth
 * changing — standalone so any screen that knows a product name (Inventory's
 * own list, the production board, wherever else a batch or a schedule entry
 * points at a product) can open the same detail view for it.
 *
 * The name is shown but not editable: it is the key that ties this record to
 * Clover's catalogue, to sales velocity, and to any batch that finished into
 * it. Renaming here would quietly orphan all three, so a rename belongs in
 * Clover, where the name actually originates.
 *
 * Callers own the data and the side effects — this component only renders
 * `item` (a normalized inventory record, see `normalizeItem` in
 * `lib/domain.js`) and calls back:
 *   - onClose()                         — dismiss with no changes
 *   - onSave(product, patch)            — commit edited threshold/max/type/unit
 *   - onRemove(product)                 — delete (only offered at zero stock)
 *   - onMove(item)                      — hand off to the caller's move flow
 * `canManage` hides every editing affordance (and the whole "manage" section
 * degrades to a read-only summary) for roles that shouldn't see it.
 */
export default function ItemModal({ item, perDay, canManage, onClose, onSave, onMove, onRemove }) {
  const family = item.type || productType(item.product);
  const [threshold, setThreshold] = useState(String(item.threshold));
  const [max, setMax] = useState(String(item.max));
  const [type, setType] = useState(family);
  const [unit, setUnit] = useState(item.unit);

  const status = stockStatus(item);
  const cover = daysOfCover(item, perDay);
  const potential = potentialCover(item, perDay);
  const short = floorDeficit(item);
  const total = totalStock(item);
  const refill = refillQty(item);
  const nextThreshold = Number(threshold);
  const nextMax = Number(max);

  const minInvalid = !Number.isFinite(nextThreshold) || nextThreshold <= 0;
  // A max at or below the min would make "full" and "too low" the same number.
  const maxInvalid = !Number.isFinite(nextMax) || nextMax <= nextThreshold;
  const invalid = minInvalid || maxInvalid;
  const dirty =
    !invalid &&
    (nextThreshold !== item.threshold ||
      nextMax !== item.max ||
      type !== family ||
      unit !== item.unit);

  return (
    <Modal
      open
      onClose={onClose}
      size="md"
      title={item.product}
      icon={STATE_ICON.floor}
      footer={
        <>
          {canManage && total === 0 && (
            <Button
              variant="ghost"
              icon={Trash2}
              className="mr-auto text-danger"
              onClick={() => onRemove(item.product)}
            >
              Delete
            </Button>
          )}
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
          {canManage && (
            <Button
              variant="primary"
              disabled={!dirty}
              onClick={() =>
                onSave(item.product, {
                  threshold: nextThreshold,
                  max: nextMax,
                  type,
                  unit: unit.trim() || "lb",
                })
              }
            >
              Save changes
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-5">
        <div className="flex items-center gap-2 flex-wrap">
          {status === "out" ? (
            <Badge tone="danger" icon={PackageX}>
              Out of stock
            </Badge>
          ) : status === "low" ? (
            <Badge tone="warn" icon={AlertTriangle}>
              Low stock
            </Badge>
          ) : (
            <Badge tone="ok">In stock</Badge>
          )}
          {canPutOut(item) && (
            <Badge tone="info" icon={ArrowRightCircle}>
              Can be covered from the back
            </Badge>
          )}
          {short > 0 && (
            <span className="text-xs text-ink-3 tnum">
              <span className="text-danger font-medium">
                {short} {item.unit} under the minimum
              </span>
              {refill > 0 && <> · bring {refill} {item.unit} to fill the case</>}
            </span>
          )}
        </div>

        {/* Where the stock physically is, in the order it moves. */}
        <div className="rounded-md border border-line overflow-hidden">
          {STOCK_STATES.map((state) => {
            const Icon = STATE_ICON[state.id];
            const qty = stockIn(item, state.id);
            return (
              <div
                key={state.id}
                className="flex items-center justify-between gap-3 px-3.5 py-2.5 border-b border-line last:border-0"
              >
                <span className="inline-flex items-center gap-2 text-sm text-ink-2">
                  <Icon size={13} className={cx("shrink-0", state.id === "freezer" && "text-cold")} />
                  {state.label}
                  <span className="text-xs text-ink-4">{state.hint}</span>
                </span>
                <span
                  className={cx(
                    "text-sm font-medium tnum",
                    state.id === "floor" ? FLOOR_TONE[status] : qty > 0 ? "text-ink" : "text-ink-4"
                  )}
                >
                  {qty} {item.unit}
                </span>
              </div>
            );
          })}
          <div className="flex items-center justify-between gap-3 px-3.5 py-2.5 bg-sunken">
            <span className="text-sm font-medium text-ink">Total</span>
            <span className="text-sm font-semibold text-ink tnum">
              {total} {item.unit}
            </span>
          </div>
        </div>

        {cover != null ? (
          <div className="flex items-start gap-2.5 px-3.5 py-3 rounded-md bg-canvas border border-line">
            <Timer
              size={15}
              className={cx(
                "shrink-0 mt-px",
                { danger: "text-danger", warn: "text-warn", ok: "text-ok", muted: "text-ink-3" }[
                  coverTone(cover)
                ]
              )}
            />
            <div className="text-xs text-ink-2 leading-relaxed">
              <span className="font-medium">{cover} days</span> of cover on the floor at the last 4
              weeks&rsquo; pace ({perDay} {item.unit}/day)
              {potential != null && potential !== cover && (
                <> · {potential} days once everything behind it is put out</>
              )}
            </div>
          </div>
        ) : (
          <p className="text-xs text-ink-4">
            No sales pace for this product yet, so there is no days-of-cover figure.
          </p>
        )}

        {canManage ? (
          <div className="space-y-4 pt-1 border-t border-line">
            <div className="grid grid-cols-2 gap-3 pt-4">
              <Field
                label={`Minimum (${unit})`}
                error={minInvalid ? "Above zero." : null}
                hint={minInvalid ? null : "Flagged low below this."}
              >
                <Input
                  type="number"
                  value={threshold}
                  invalid={minInvalid}
                  onChange={(e) => setThreshold(e.target.value)}
                  className="tnum"
                />
              </Field>

              <Field
                label={`Full case (${unit})`}
                error={maxInvalid ? "Must exceed the minimum." : null}
                hint={maxInvalid ? null : "What a stocker fills to."}
              >
                <Input
                  type="number"
                  value={max}
                  invalid={maxInvalid}
                  onChange={(e) => setMax(e.target.value)}
                  className="tnum"
                />
              </Field>
            </div>

            <Field label="Family" hint="Guessed from the name — correct it if the guess is wrong.">
              <Segmented
                size="sm"
                scroll
                value={type}
                onChange={setType}
                options={PRODUCT_TYPES.map((t) => ({ value: t, label: t }))}
              />
            </Field>

            <Field label="Unit" hint="Whatever this product is counted in.">
              <Input value={unit} onChange={(e) => setUnit(e.target.value)} className="max-w-24" />
            </Field>
          </div>
        ) : (
          <p className="text-xs text-ink-4 border-t border-line pt-4">
            Minimum {item.threshold} {item.unit} · full case {item.max} {item.unit} · {family}. Ask a
            manager to change these.
          </p>
        )}

        {total > 0 && (
          <Button
            block
            variant="secondary"
            icon={ArrowRightCircle}
            onClick={() => onMove(item)}
          >
            Move stock
          </Button>
        )}
      </div>
    </Modal>
  );
}
