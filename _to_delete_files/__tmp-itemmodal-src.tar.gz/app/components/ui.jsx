"use client";

/**
 * UI primitives.
 *
 * Every surface in the product is composed from these — screens never reach for
 * raw colour or spacing utilities. Variants are plain objects rather than a
 * class-variance library so there's no dependency to keep in step.
 */

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AlertTriangle, CheckCircle2, ChevronDown, Info, Loader2, Search, X } from "lucide-react";

export const cx = (...parts) => parts.filter(Boolean).join(" ");

/* ------------------------------------------------------------------ Slots -- */

/**
 * Named portals from a screen into the app shell.
 *
 * A page's own actions — "Add product", a data-source status, a refresh —
 * belong beside the page title, not stacked into the middle of the content
 * where they read as one more filter. But the title is rendered by the shell
 * and the handlers live in the screen, so the screen posts into a slot the
 * shell put there.
 *
 * A ref callback sets the target once, so there is no state to keep in step
 * and no render loop to guard against.
 */
const SlotContext = createContext(null);

export function SlotProvider({ children }) {
  const [nodes, setNodes] = useState({});
  const register = useCallback((name, el) => {
    setNodes((n) => (n[name] === el ? n : { ...n, [name]: el }));
  }, []);
  return <SlotContext.Provider value={{ nodes, register }}>{children}</SlotContext.Provider>;
}

/** Renders where the slot's contents should appear. Empty until a screen fills it. */
export function SlotTarget({ name, className }) {
  const ctx = useContext(SlotContext);
  const register = ctx?.register;
  const ref = useCallback((el) => register?.(name, el), [register, name]);
  return <div ref={ref} className={className} />;
}

/** Renders its children into the named target. No-op until the target mounts. */
export function Slot({ name, children }) {
  const ctx = useContext(SlotContext);
  const el = ctx?.nodes?.[name];
  return el ? createPortal(children, el) : null;
}

/* ---------------------------------------------------------------- Button -- */

const BTN_BASE =
  "inline-flex items-center justify-center gap-1.5 font-medium rounded-md " +
  "transition-colors duration-100 select-none whitespace-nowrap " +
  "disabled:cursor-not-allowed disabled:opacity-55";

// No variant carries a resting shadow. `primary` is the one filled accent on a
// screen — a second one on the same view breaks the under-1% coverage budget.
const BTN_VARIANT = {
  primary: "bg-primary text-white hover:bg-primary-hover",
  secondary: "bg-transparent text-ink border border-line-strong hover:bg-hover",
  ghost: "bg-transparent text-ink-2 hover:bg-hover hover:text-ink",
  success: "bg-transparent text-ok border border-ok-line hover:bg-ok-soft",
  danger: "bg-transparent text-danger border border-danger-line hover:bg-danger-soft",
  subtle: "bg-hover text-ink hover:bg-faint",
};

// Heights come from the density variables, so a station tablet gets a 44px
// target and a desk gets Notion's 28px without either being a special case.
const BTN_SIZE = {
  sm: "text-xs px-2 h-[var(--ctl-h)]",
  md: "text-sm px-2.5 h-[var(--ctl-h)]",
  lg: "text-sm px-3 h-[var(--ctl-h-lg)]",
};

export function Button({
  variant = "secondary",
  size = "md",
  icon: Icon,
  iconRight: IconRight,
  loading = false,
  block = false,
  className,
  children,
  disabled,
  ...rest
}) {
  const iconSize = size === "sm" ? 12 : 16;
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={cx(BTN_BASE, BTN_VARIANT[variant], BTN_SIZE[size], block && "w-full", className)}
    >
      {loading ? (
        <Loader2 size={iconSize} className="animate-spin shrink-0" />
      ) : (
        Icon && <Icon size={iconSize} className="shrink-0" />
      )}
      {children}
      {IconRight && !loading && <IconRight size={iconSize} className="shrink-0" />}
    </button>
  );
}

export function IconButton({ label, icon: Icon, size = 16, className, ...rest }) {
  return (
    <button
      {...rest}
      aria-label={label}
      title={label}
      className={cx(
        "inline-flex items-center justify-center rounded-md shrink-0",
        "w-[var(--ctl-h)] h-[var(--ctl-h)]",
        "text-icon-2 hover:text-icon hover:bg-hover transition-colors duration-100",
        className
      )}
    >
      <Icon size={size} />
    </button>
  );
}

/* ------------------------------------------------------------------ Card -- */

export function Card({ as: Tag = "div", inset = false, className, children, ...rest }) {
  return (
    <Tag
      {...rest}
      className={cx(
        // Not a card. A section is two rules — one above, one below — and the
        // page showing through between them. No side borders, no radius, no
        // shadow: the DNA bans wrapping a GROUP in a box, and every one of
        // these held a group.
        "bg-surface border-y border-line",
        inset && "py-3",
        className
      )}
    >
      {children}
    </Tag>
  );
}

export function CardHeader({ title, subtitle, icon: Icon, actions, className }) {
  return (
    <div
      className={cx(
        "flex items-start justify-between gap-3 py-2.5 border-b border-line",
        className
      )}
    >
      <div className="min-w-0">
        <div className="flex items-center gap-2 text-sm font-medium text-ink">
          {Icon && <Icon size={16} className="text-icon-2 shrink-0" />}
          <span className="truncate">{title}</span>
        </div>
        {/* Same size as the title, separated by colour alone — the flat scale. */}
        {subtitle && <p className="mt-0.5 text-sm text-ink-2">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}

export function CardBody({ className, children }) {
  return <div className={cx("py-3", className)}>{children}</div>;
}

/* ----------------------------------------------------------------- Badge -- */

const BADGE_TONE = {
  neutral: "bg-sunken text-ink-2 border-line",
  ok: "bg-ok-soft text-ok border-ok-line",
  warn: "bg-warn-soft text-warn border-warn-line",
  danger: "bg-danger-soft text-danger border-danger-line",
  // Not the accent. A role chip is not the next action on the screen.
  info: "bg-hover text-ink-2 border-transparent",
  cold: "bg-cold-soft text-cold border-cold-soft",
};

export function Badge({ tone = "neutral", icon: Icon, className, children }) {
  return (
    <span
      className={cx(
        "inline-flex items-center gap-1 px-2 h-5 rounded-full border",
        "text-xs font-medium whitespace-nowrap",
        BADGE_TONE[tone],
        className
      )}
    >
      {Icon && <Icon size={12} className="shrink-0" />}
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ Kbd/Meta */

export function MetaRow({ className, children }) {
  return (
    <div className={cx("flex items-center flex-wrap gap-x-3 gap-y-1 text-xs text-ink-3", className)}>
      {children}
    </div>
  );
}

/* ----------------------------------------------------------------- Fields -- */

export function Label({ htmlFor, className, children }) {
  return (
    <label
      htmlFor={htmlFor}
      className={cx("block text-xs font-medium text-ink-3 mb-1.5", className)}
    >
      {children}
    </label>
  );
}

export function Field({ label, hint, error, htmlFor, className, children }) {
  return (
    <div className={className}>
      {label && <Label htmlFor={htmlFor}>{label}</Label>}
      {children}
      {error ? (
        <p className="mt-1.5 text-xs text-danger">{error}</p>
      ) : (
        hint && <p className="mt-1.5 text-xs text-ink-3">{hint}</p>
      )}
    </div>
  );
}

const INPUT_BASE =
  "w-full bg-surface border text-ink placeholder:text-ink-4 " +
  "transition-colors duration-100 focus:border-primary outline-none " +
  "disabled:bg-sunken disabled:text-ink-3";

/**
 * `pill` is for an input that sits in a row of chips — a weight range beside
 * the filters it narrows. It has to take the chips' shape and size or it reads
 * as a different class of control sitting in the wrong row.
 */
export function Input({ invalid, pill = false, className, size = "md", ...rest }) {
  const shape = pill
    ? "rounded-full px-3 text-xs h-[var(--ctl-h)]"
    : size === "lg"
      ? "rounded-md px-2.5 text-sm h-[var(--ctl-h-lg)]"
      : "rounded-md px-2.5 text-sm h-[var(--ctl-h)]";
  return (
    <input
      {...rest}
      aria-invalid={invalid || undefined}
      className={cx(INPUT_BASE, shape, invalid ? "border-danger" : "border-line-strong", className)}
    />
  );
}

/** Numeric PIN entry — large, spaced, never remembered by the browser. */
export function PinInput({ invalid, className, ...rest }) {
  return (
    <input
      {...rest}
      type="password" inputMode="numeric" autoComplete="off" maxLength={4}
      placeholder="••••" aria-invalid={invalid || undefined}
      className={cx(
        INPUT_BASE,
        "rounded-md px-3 h-[var(--ctl-h-lg)] text-base tracking-[0.4em] font-mono",
        invalid ? "border-danger" : "border-line-strong",
        className
      )}
    />
  );
}

export function SearchInput({ value, onChange, placeholder = "Search…", pill = false, className }) {
  return (
    <div
      className={cx(
        "flex items-center gap-2 h-[var(--ctl-h)] bg-surface border border-line-strong",
        // The ring belongs to the whole pill, not just the <input> inside it —
        // drawn here on focus-within, with the input's own ring switched off,
        // so a focused search field stays one unbroken shape.
        "focus-within:border-primary focus-within:shadow-[0_0_0_2px_var(--color-canvas),0_0_0_4px_var(--color-primary)]",
        "transition-colors duration-100",
        pill ? "rounded-full px-3" : "rounded-md px-2.5",
        className
      )}
    >
      <Search size={14} className="text-icon-2 shrink-0" />
      {/* type="text", not "search" — Safari/Chrome each draw their own
          cancel glyph and field decoration on a search input, on top of the
          clear button below. One clear affordance, drawn by us. */}
      <input
        type="text" inputMode="search" autoComplete="off" value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="flex-1 min-w-0 h-full bg-transparent border-0 outline-none focus-visible:shadow-none text-sm text-ink placeholder:text-ink-4 [&::-webkit-search-cancel-button]:hidden"
      />
      {value && <IconButton label="Clear search" icon={X} size={13} onClick={() => onChange("")} className="w-5 h-5 shrink-0" />}
    </div>
  );
}

/**
 * A hover label for a control whose meaning isn't self-evident from its
 * text alone — built, not the native `title` attribute, which every browser
 * delays and styles differently (and some skip on touch entirely). Keyboard
 * focus shows it too, so it isn't a mouse-only explanation.
 */
export function Tooltip({ label, children, side = "top", className }) {
  const [open, setOpen] = useState(false);
  const timerRef = useRef(null);

  const show = () => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setOpen(true), 350);
  };
  const hide = () => {
    clearTimeout(timerRef.current);
    setOpen(false);
  };
  useEffect(() => () => clearTimeout(timerRef.current), []);

  return (
    <span
      className={cx("relative inline-flex shrink-0", className)}
      onMouseEnter={show}
      onMouseLeave={hide}
      onFocus={show}
      onBlur={hide}
    >
      {children}
      {open && (
        <span
          role="tooltip"
          className={cx(
            "pointer-events-none absolute z-40 left-1/2 -translate-x-1/2 whitespace-nowrap",
            "px-2 py-1 rounded-md bg-ink text-white text-xs font-medium shadow-md animate-fade-in",
            side === "top" ? "bottom-full mb-1.5" : "top-full mt-1.5"
          )}
        >
          {label}
        </span>
      )}
    </span>
  );
}

/**
 * A filter that opens a menu instead of a row of pills — built, not the OS
 * widget. The native `<select>` renders whatever chrome the platform feels
 * like that week; this one is the same hairline-and-ring surface as every
 * other floating panel in the system, and it matches its trigger's height and
 * radius exactly, which no native control can promise across browsers.
 *
 * `on` marks the trigger as active (non-default) the same way FilterChip did.
 */
export function Dropdown({
  value,
  onChange,
  options,
  icon: Icon,
  on = false,
  disabled,
  className,
  menuSide = "bottom",
  // A strip pinned inside the menu itself — an A–Z toggle, a quick filter,
  // anything that acts on the option list below it rather than being one of
  // its choices. `pinnedSide` puts it above or below the scrolling options,
  // set off by its own hairline so it never reads as a selectable row.
  pinned,
  pinnedSide = "top",
  "aria-label": ariaLabel,
}) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const current = options.find((o) => o.value === value);

  return (
    <div ref={rootRef} className={cx("relative inline-block shrink-0", className)}>
      <button
        type="button"
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={ariaLabel}
        onClick={() => setOpen((o) => !o)}
        className={cx(
          "inline-flex items-center gap-1.5 px-2.5 h-[var(--ctl-h)] rounded-full border",
          "text-xs font-medium transition-colors duration-100 max-w-[11rem]",
          "disabled:opacity-45 disabled:cursor-not-allowed",
          on ? "border-line-strong bg-hover text-ink" : "border-line bg-surface text-ink-2 hover:bg-hover"
        )}
      >
        {Icon && <Icon size={12} className="shrink-0" />}
        <span className="truncate">{current?.label ?? ""}</span>
        <ChevronDown
          size={12}
          className={cx("shrink-0 text-ink-4 transition-transform duration-100", open && "rotate-180")}
        />
      </button>

      {open && (
        // `menuSide` flips the menu to open upward — a dropdown near the
        // bottom of the viewport (a sort control under a long list, say)
        // shouldn't have to render off-screen to stay below its trigger.
        <div
          role="listbox"
          className={cx(
            "absolute z-30 left-0 w-max max-w-[16rem] rounded-md border border-line-strong bg-surface shadow-md overflow-hidden",
            menuSide === "top" ? "bottom-full mb-1 min-w-full" : "top-full mt-1 min-w-full"
          )}
        >
          {pinned && pinnedSide === "top" && (
            <div className="px-2 py-1.5 border-b border-line">{pinned}</div>
          )}
          <div className="py-1">
            {options.map((o) => {
              const active = o.value === value;
              return (
                <button
                  key={o.value}
                  type="button"
                  role="option"
                  aria-selected={active}
                  onClick={() => {
                    onChange(o.value);
                    setOpen(false);
                  }}
                  className={cx(
                    "w-full flex items-center gap-2 text-left px-3 h-[var(--row-h)] text-sm truncate",
                    active ? "bg-hover text-ink font-medium" : "text-ink-2 hover:bg-faint hover:text-ink"
                  )}
                >
                  {o.icon && <o.icon size={13} className="shrink-0 text-ink-4" />}
                  {o.label}
                </button>
              );
            })}
          </div>
          {pinned && pinnedSide === "bottom" && (
            <div className="px-2 py-1.5 border-t border-line">{pinned}</div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------- Segmented -- */

/** A small notification dot for a tab: a count badge, not a status label —
 *  always the brand color, so it reads as "count" rather than a severity
 *  signal. Pinned to the tab's top-right corner. Zero renders nothing — an
 *  empty dot just adds noise. */
function TabDot({ count }) {
  if (!count) return null;
  return (
    <span
      className={cx(
        "absolute -top-1.5 -right-1.5 inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full",
        "text-[10px] font-semibold leading-none tnum shrink-0 ring-2 ring-surface",
        "bg-primary text-white"
      )}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

export function Segmented({ options, value, onChange, size = "md", className, scroll = false }) {
  const pad = size === "sm" ? "text-xs px-2 h-[var(--ctl-h)]" : "text-sm px-2.5 h-[var(--ctl-h)]";
  return (
    <div
      role="tablist" className={cx(
        // No track. The chips sit on the page and the active one takes the 5% tint.
        "inline-flex gap-1",
        scroll && "max-w-full overflow-x-auto no-scrollbar",
        className
      )}
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            role="tab" aria-selected={active}
            disabled={o.disabled}
            onClick={() => onChange(o.value)}
            className={cx(
              "relative inline-flex items-center justify-center gap-1.5 rounded-md font-medium shrink-0",
              "transition-colors duration-100 disabled:opacity-45 disabled:cursor-not-allowed",
              pad,
              active ? "bg-hover text-ink" : "text-ink-2 hover:bg-faint hover:text-ink"
            )}
          >
            {o.icon && <o.icon size={16} className="shrink-0" />}
            {o.label}
            {o.count != null && <TabDot count={o.count} />}
          </button>
        );
      })}
    </div>
  );
}

/* ----------------------------------------------------------------- Switch */

export function Switch({ checked, onChange, disabled, label, className }) {
  return (
    <button
      type="button" role="switch" aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cx(
        "relative inline-flex h-6 w-10 shrink-0 items-center rounded-full",
        "transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed",
        checked ? "bg-primary" : "bg-line-strong",
        className
      )}
    >
      <span
        className={cx(
          "inline-block h-4 w-4 transform rounded-full bg-white",
          "transition-transform duration-150",
          checked ? "translate-x-5" : "translate-x-1"
        )}
      />
    </button>
  );
}

/* ---------------------------------------------------------------- StatCard */

/**
 * A number, and — when `onClick` is given — the filter that number describes.
 * Making the tile the control means the count and the way to act on it are the
 * same target, rather than a stat you then have to go and reproduce by hand.
 */
export function StatCard({
  icon: Icon,
  label,
  value,
  unit,
  hint,
  tone = "neutral",
  onClick,
  active = false,
}) {
  const toneClass = {
    neutral: "text-ink",
    ok: "text-ok",
    warn: "text-warn",
    danger: "text-danger",
    primary: "text-ink",
  }[tone];

  const Tag = onClick ? "button" : "div";

  return (
    <Tag
      {...(onClick
        ? { onClick, type: "button", "aria-pressed": active, className: undefined }
        : {})}
      className={cx(
        "border rounded-md px-3.5 py-2.5 text-left w-full transition-colors duration-100",
        // Selection is the 5% tint and a firmer hairline — never a colour wash.
        active ? "border-line-strong bg-hover" : "border-line bg-surface",
        onClick && !active && "hover:bg-faint cursor-pointer"
      )}
    >
      <div className="flex items-center gap-1.5 text-ink-3 mb-1">
        {Icon && <Icon size={12} className="shrink-0" />}
        <span className="text-xs font-medium truncate">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        {/* 24px against 14px body = 1.7:1. The tile is a number, not a headline. */}
        <span className={cx("text-2xl font-semibold tnum leading-none", toneClass)}>{value}</span>
        {unit && <span className="text-xs text-ink-3 font-medium">{unit}</span>}
      </div>
      {hint && <div className="mt-1 text-xs text-ink-3 truncate">{hint}</div>}
    </Tag>
  );
}

export function StatGrid({ className, children }) {
  return (
    <div
      className={cx("grid grid-cols-2 lg:grid-cols-4 gap-2", className)}>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------ ProgressBar -- */

export function ProgressBar({ value, tone = "primary", size = "md", className }) {
  const toneClass = {
    primary: "bg-primary",
    ok: "bg-ok",
    warn: "bg-warn",
    danger: "bg-danger",
    muted: "bg-line-strong",
  }[tone];
  const h = size === "sm" ? "h-1" : "h-1.5";
  return (
    <div className={cx("flex-1 rounded-full bg-inset overflow-hidden", h, className)}>
      {/* width is a runtime percentage, so it stays an inline style */}
      <div
        className={cx("rounded-full transition-[width] duration-300", h, toneClass)}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

/* ------------------------------------------------------------- EmptyState -- */

export function EmptyState({ icon: Icon, title, description, action, className }) {
  return (
    // State the absence, offer the one action, in a sentence. No centred card,
    // no illustration, no bordered box — the DNA bans all three.
    <div className={cx("px-3 py-8", className)}>
      <p className="text-sm text-ink-3">
        {title}
        {description && <span className="text-ink-4"> — {description}</span>}
      </p>
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

/* -------------------------------------------------------------- Skeleton -- */

export function Skeleton({ className }) {
  return <div className={cx("skeleton rounded-sm", className)} />;
}

export function SkeletonRows({ rows = 3 }) {
  return (
    <div className="ruled border-t border-line" aria-hidden="true">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="px-3 py-3">
          <Skeleton className="h-3.5 w-40 mb-2" />
          <Skeleton className="h-3 w-64" />
        </div>
      ))}
    </div>
  );
}

/* ----------------------------------------------------------------- Modal -- */

/**
 * Bottom sheet on phones, centred dialog from `sm` up. Closes on Escape and on
 * backdrop click; focus is moved into the panel on open.
 */
export function Modal({ open, onClose, title, icon: Icon, footer, size = "sm", children }) {
  const panelRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && onClose?.();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panelRef.current?.querySelector("input, button, [tabindex]")?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  const width = { sm: "sm:max-w-sm", md: "sm:max-w-md", lg: "sm:max-w-lg" }[size];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center animate-fade-in">
      <div
        className="absolute inset-0 bg-ink/60" onClick={onClose}
        aria-hidden="true"
      />
      <div
        ref={panelRef}
        role="dialog" aria-modal="true" aria-label={title}
        className={cx(
          "relative w-full bg-surface shadow-pop",
          "rounded-t-md sm:rounded-md sm:m-4 pb-safe sm:pb-0",
          // A column with a capped height: the header and footer hold their
          // ground and the body scrolls, so a long dialog never pushes its own
          // actions off the bottom of the screen. dvh rather than vh because
          // mobile browser chrome makes vh overshoot.
          "flex flex-col max-h-[88dvh] sm:max-h-[calc(100dvh-2rem)]",
          "animate-slide-up sm:animate-pop-in",
          width
        )}
      >
        {title && (
          <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-3">
            <div className="flex items-center gap-2 min-w-0">
              {Icon && <Icon size={16} className="text-icon-2 shrink-0" />}
              <h2 className="text-sm font-medium text-ink truncate">{title}</h2>
            </div>
            <IconButton label="Close" icon={X} size={17} onClick={onClose} />
          </div>
        )}
        <div className="flex-1 min-h-0 overflow-y-auto thin-scrollbar px-4 pb-4">{children}</div>
        {footer && (
          <div className="shrink-0 flex items-center justify-end gap-2 px-4 py-3 border-t border-line rounded-b-md">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- Toasts -- */

const ToastContext = createContext(() => {});
export const useToast = () => useContext(ToastContext);

const TOAST_ICON = { success: CheckCircle2, error: AlertTriangle, info: Info };
const TOAST_ACCENT = {
  success: "text-ok",
  error: "text-danger",
  info: "text-primary",
};

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const seq = useRef(0);

  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const toast = useCallback(
    (message, { tone = "success", detail, duration = 4000 } = {}) => {
      const id = ++seq.current;
      setToasts((t) => [...t, { id, message, detail, tone }]);
      if (duration) setTimeout(() => dismiss(id), duration);
      return id;
    },
    [dismiss]
  );

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <div
        role="status" aria-live="polite" className={cx(
          "fixed z-[60] flex flex-col gap-2 pointer-events-none",
          // Above the mobile tab bar on phones, bottom-right on desktop.
          "left-4 right-4 bottom-20 items-stretch",
          "sm:left-auto sm:right-5 sm:bottom-5 sm:w-80 sm:items-end"
        )}
      >
        {toasts.map((t) => {
          const Icon = TOAST_ICON[t.tone];
          return (
            <div
              key={t.id}
              className={cx(
                "pointer-events-auto w-full flex items-start gap-2.5 px-3 py-2.5",
                "bg-surface rounded-md shadow-md animate-toast-in"
              )}
            >
              <Icon size={16} className={cx("shrink-0 mt-px", TOAST_ACCENT[t.tone])} />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink">{t.message}</p>
                {t.detail && <p className="mt-0.5 text-xs text-ink-3">{t.detail}</p>}
              </div>
              <IconButton label="Dismiss" icon={X} size={14} onClick={() => dismiss(t.id)} className="w-6 h-6 -mr-1 -mt-0.5" />
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}
