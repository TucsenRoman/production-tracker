"use client";

import React, { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowUpFromLine,
  Check,
  ClipboardCheck,
  Factory,
  Pencil,
  Plus,
  Snowflake,
} from "lucide-react";

import {
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  Segmented,
  StickyFadeHeader,
  cx,
} from "../../components/ui";
import {
  STATIONS,
  behindStock,
  normalizeItem,
  refillQty,
  stockIn,
  shiftDate,
  weekOf,
} from "../../lib/domain";

/**
 * Console-side production targets.
 *
 * The flow this screen runs, in the order a manager actually thinks it:
 *
 *   1. here is what is on the floor
 *   2. here is the min and the max it should sit between
 *   3. so here is what you should plan — and how much of that is a run
 *      versus stock already sitting in the back
 *   4. disagree? change the amount, or change the min and max themselves
 *
 * Every number comes from the domain's own vocabulary rather than a private
 * one invented here: `threshold` is the min, `max` the fill target,
 * `refillQty` the gap between the floor and that max, `behindStock` what
 * could be put out without making anything at all.
 *
 * That last one is why the recommendation is split. "Plan 82 lb" is wrong
 * when 42 lb of it is already in the freezer — the honest answer is move 42
 * and make 40, and a screen that says 82 sends someone to smoke bacon that
 * already exists.
 *
 * The day-by-day strip stayed on the floor Board, where a shift is genuinely
 * working one day at a time. A manager is deciding what to commit, not what
 * is happening at 2pm on Thursday.
 */

const STATE = {
  below: { label: "Below min", tone: "warn", rank: 0 },
  make: { label: "Needs a run", tone: "neutral", rank: 1 },
  move: { label: "Move from back", tone: "cold", rank: 2 },
  planned: { label: "Planned", tone: "info", rank: 3 },
  full: { label: "On hand", tone: "ok", rank: 4 },
};

export default function ProductionScreen({
  schedule,
  inventory,
  batches = [],
  today,
  onSetRange,
  onAddTask,
}) {
  const [tab, setTab] = useState("attention");

  const week = useMemo(() => weekOf(today), [today]);
  /* Where an accepted plan lands: today if it's a production day, else the
   * next one. A manager shouldn't have to pick a date to say "yes, make it". */
  const defaultDay = useMemo(() => {
    const day = week.find((d) => d.isProductionDay && d.key >= today);
    return day ? day.key : today;
  }, [week, today]);

  const rows = useMemo(() => {
    /* What is already committed against each product: runs booked on days
     * that haven't happened, plus batches physically in flight. Today's
     * schedule rows are skipped because adding one on today spawns a batch
     * too, and counting both would double-book a product against itself. */
    const committed = new Map();
    const bump = (product, n) =>
      committed.set(product, (committed.get(product) || 0) + n);

    /* A rolling window forward, NOT the rest of the calendar week. On a
     * Friday the current week has no production days left, so a week-bounded
     * scan could never see a plan at all and everything read as unplanned —
     * including runs booked for Monday. A plan is a plan regardless of which
     * week it falls in. Today is excluded because adding a run on today
     * spawns a batch too, and both would count. */
    for (let i = 1; i <= 7; i += 1) {
      const key = shiftDate(today, i);
      const dow = new Date(`${key}T00:00:00`).getDay();
      if (dow === 0 || dow === 6) continue; // no production at the weekend
      for (const station of STATIONS) {
        for (const t of (schedule[key] || {})[station] || []) {
          bump(t.text, Number(t.qty) || 0);
        }
      }
    }
    for (const b of batches) {
      if (b.finalWeight != null) continue; // already landed in stock
      bump(b.product, Number(b.boxWeight ?? b.estWeight) || 0);
    }

    return inventory
      .map(normalizeItem)
      .map((item) => {
        const floor = stockIn(item, "floor");
        const behind = behindStock(item);
        const refill = refillQty(item);
        const fromBack = Math.min(refill, behind);
        const toMake = Math.max(0, +(refill - behind).toFixed(1));
        const planned = committed.get(item.product) || 0;

        let state;
        if (refill <= 0) state = "full";
        else if (planned >= toMake && toMake > 0) state = "planned";
        else if (floor < item.threshold) state = "below";
        else if (toMake > 0) state = "make";
        else state = "move";

        return { item, floor, behind, refill, fromBack, toMake, planned, state };
      })
      .sort(
        (a, b) =>
          STATE[a.state].rank - STATE[b.state].rank ||
          b.refill - a.refill ||
          a.item.product.localeCompare(b.item.product),
      );
  }, [inventory, schedule, batches, today]);

  /* Three states a product can be in, as tabs rather than one long mixed
   * list: something you still have to decide about, something already
   * committed, and something that needs nothing. They're read at different
   * moments — you work the first, check the second, and ignore the third. */
  const groups = useMemo(
    () => ({
      attention: rows.filter((r) => ["below", "make", "move"].includes(r.state)),
      planned: rows.filter((r) => r.state === "planned"),
      stocked: rows.filter((r) => r.state === "full"),
    }),
    [rows],
  );

  const shown = groups[tab] || [];
  const totalToMake = groups.attention.reduce(
    (n, r) => n + Math.max(0, r.toMake - r.planned),
    0,
  );
  const totalToMove = groups.attention.reduce((n, r) => n + r.fromBack, 0);
  const belowMin = rows.filter((r) => r.state === "below").length;

  return (
    <div>
      <StickyFadeHeader pad={28}>
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <Segmented
            fade
            value={tab}
            onChange={setTab}
            options={[
              {
                value: "attention",
                label: "Needs a plan",
                icon: AlertTriangle,
                count: groups.attention.length || undefined,
              },
              {
                value: "planned",
                label: "Planned",
                icon: ClipboardCheck,
                count: groups.planned.length || undefined,
              },
              {
                value: "stocked",
                label: "On hand",
                icon: Check,
                count: groups.stocked.length || undefined,
              },
            ]}
          />

          <span className="text-xs text-ink-3 tnum shrink-0">
            {belowMin > 0 && (
              <span className="text-warn font-medium">{belowMin} below min · </span>
            )}
            {Math.round(totalToMove)} lb to move · {Math.round(totalToMake)} lb to make
          </span>
        </div>
      </StickyFadeHeader>

      {shown.length === 0 ? (
        <Card>
          <EmptyState
            icon={Check}
            title={
              tab === "attention"
                ? "Nothing waiting on a decision"
                : tab === "planned"
                  ? "Nothing planned yet"
                  : "Nothing fully on hand"
            }
            description={
              tab === "attention"
                ? "Every product is either planned for or already on hand."
                : tab === "planned"
                  ? "Runs you add from the other tab show up here."
                  : "Every case is below its max right now."
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-3">
          {shown.map((row) => (
            <PlanCard
              key={row.item.product}
              row={row}
              defaultDay={defaultDay}
              onSetRange={onSetRange}
              onAddTask={onAddTask}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ parts -- */

/**
 * The case, drawn as a case: a column from empty to max, filled to where the
 * floor actually is, with the min drawn across it as a line you can be under.
 * The pale segment above the fill is what accepting this plan would add, so
 * the decision and its effect are the same picture.
 */
function Gauge({ floor, min, max, adding }) {
  const pct = (n) => (max > 0 ? Math.max(0, Math.min(100, (n / max) * 100)) : 0);
  return (
    <div className="relative w-7 h-24 shrink-0 rounded-md bg-inset border border-line overflow-hidden">
      {adding > 0 && (
        <span
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 bg-cold-soft"
          style={{ height: `${pct(floor + adding)}%` }}
        />
      )}
      <span
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 bg-ink-2"
        style={{ height: `${pct(floor)}%` }}
      />
      <span
        aria-hidden="true"
        title={`Minimum ${min}`}
        className="absolute inset-x-0 h-0.5 bg-warn"
        style={{ bottom: `${pct(min)}%` }}
      />
    </div>
  );
}

function PlanCard({ row, defaultDay, onSetRange, onAddTask }) {
  const { item, floor, behind, refill, fromBack, toMake, planned, state } = row;
  const s = STATE[state];

  const suggested = Math.max(0, Math.round(toMake - planned));
  const [qty, setQty] = useState(String(suggested || Math.round(refill)));
  const [station, setStation] = useState(STATIONS[0]);
  const [editingRange, setEditingRange] = useState(false);
  const [min, setMin] = useState(String(item.threshold));
  const [max, setMax] = useState(String(item.max));

  const n = Number(qty) || 0;

  return (
    <div className="flex flex-col gap-3 border border-line rounded-md bg-surface px-3.5 py-3">
      <div className="flex items-start justify-between gap-2">
        <span className="text-sm font-medium text-ink min-w-0 truncate">
          {item.product}
        </span>
        <Badge tone={s.tone} icon={state === "full" ? Check : undefined}>
          {s.label}
        </Badge>
      </div>

      {/* 1 + 2 — what's on the floor, and the band it should sit in. */}
      <div className="flex items-end gap-3">
        <Gauge floor={floor} min={item.threshold} max={item.max} adding={n} />
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-semibold tnum leading-none text-ink">
              {floor}
            </span>
            <span className="text-xs text-ink-3">{item.unit} on the floor</span>
          </div>

          {editingRange ? (
            <div className="mt-2 flex items-center gap-1.5">
              <span className="w-16 shrink-0">
                <Input
                  type="number"
                  value={min}
                  onChange={(e) => setMin(e.target.value)}
                  className="tnum"
                  aria-label="Minimum"
                />
              </span>
              <span className="text-xs text-ink-4">to</span>
              <span className="w-16 shrink-0">
                <Input
                  type="number"
                  value={max}
                  onChange={(e) => setMax(e.target.value)}
                  className="tnum"
                  aria-label="Maximum"
                />
              </span>
              <Button
                size="sm"
                variant="primary"
                onClick={() => {
                  onSetRange(item.product, {
                    threshold: Number(min) || 0,
                    max: Number(max) || 0,
                  });
                  setEditingRange(false);
                }}
              >
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditingRange(false)}>
                Cancel
              </Button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setEditingRange(true)}
              title="Change the min and max"
              className="mt-1 inline-flex items-center gap-1.5 text-xs text-ink-3 tnum hover:text-ink hover:underline"
            >
              min {item.threshold} · max {item.max} {item.unit}
              <Pencil size={11} className="shrink-0" />
            </button>
          )}
        </div>
      </div>

      {/* 3 — the recommendation, and why it isn't just "the gap". */}
      <div className="text-xs text-ink-3 space-y-0.5 tnum">
        {refill > 0 ? (
          <p className="text-ink-2">
            <span className="font-medium text-ink">
              Plan {Math.round(refill)} {item.unit}
            </span>{" "}
            to fill the case
          </p>
        ) : (
          <p>At or above max — nothing to plan.</p>
        )}
        {fromBack > 0 && (
          <p className="flex items-center gap-1.5">
            <Snowflake size={11} className="text-cold shrink-0" />
            {Math.round(fromBack)} {item.unit} already in back — move it, don&rsquo;t make it
          </p>
        )}
        {toMake > 0 && (
          <p className="flex items-center gap-1.5">
            <Factory size={11} className="text-ink-3 shrink-0" />
            {Math.round(toMake)} {item.unit} needs a run
          </p>
        )}
        {planned > 0 && (
          <p className="flex items-center gap-1.5 text-cold">
            <Check size={11} className="shrink-0" />
            {Math.round(planned)} {item.unit} already planned
          </p>
        )}
      </div>

      {/* 4 — disagree? change it, then commit.
       *
       *  Hidden entirely when there's nothing to fill: a quantity box reading
       *  0 beside a greyed-out button is a dead control, and it sat directly
       *  under a line already saying "nothing to plan". Building stock ahead
       *  of a product's max is a Board decision, not a gap to close here. */}
      {refill > 0 && (
      <div className="flex items-center gap-1.5 mt-auto pt-0.5 flex-wrap">
        {/* INPUT_BASE carries `w-full`, which inside a wrapping flex row
         *  takes the whole line — so the width lives on a wrapper. */}
        <span className="w-16 shrink-0">
          <Input
            type="number"
            value={qty}
            onChange={(e) => setQty(e.target.value)}
            className="tnum"
            aria-label={`Amount to plan for ${item.product}`}
          />
        </span>
        <Segmented
          size="sm"
          value={station}
          onChange={setStation}
          options={STATIONS.map((st) => ({ value: st, label: st }))}
        />
        <Button
          size="sm"
          variant={state === "below" ? "primary" : "secondary"}
          icon={fromBack >= refill && refill > 0 ? ArrowUpFromLine : Plus}
          disabled={n <= 0}
          onClick={() => onAddTask(defaultDay, station, item.product, n)}
        >
          Add to plan
        </Button>
      </div>
      )}
    </div>
  );
}
