"use client";

import React, { useMemo, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  History,
  MessageCircle,
  Send,
  Sparkles,
  TrendingUp,
} from "lucide-react";

import { Button, Card, Input, StatCard, StatGrid, StickyFadeHeader, cx } from "../../components/ui";
import { formatDay, yieldPct } from "../../lib/domain";
import { answerInsightQuestion, isFlaggedBatch } from "../lib/insights";

/* -------------------------------------------------------------- Insights -- */

const INSIGHT_TONE_ICON = { warn: AlertTriangle, danger: AlertTriangle, ok: CheckCircle2, neutral: Sparkles };
const INSIGHT_TONE_ICON_CLASS = { warn: "text-warn", danger: "text-danger", ok: "text-ok", neutral: "text-ink-2" };

/**
 * Each tone gets a genuinely different card, not just a different icon —
 * border colour and a soft tint, the exact same `border-{tone}-line
 * bg-{tone}-soft` pairing BoardScreen already uses for its over-target
 * warning card. "Box a thing you can click, rule a thing you only read"
 * (see [[screen-critique-pass]]) is why these are individually bordered
 * boxes at all: every card here has its own "Ask about this" control, so
 * it's a click target, not a read-only row.
 */
const TONE_CARD_CLASS = {
  neutral: "border-line bg-surface",
  ok: "border-ok-line bg-ok-soft",
  warn: "border-warn-line bg-warn-soft",
  danger: "border-danger-line bg-danger-soft",
};

/**
 * The one header treatment shared by the two stacked cards below.
 * Hand-rolled rather than the shared `CardHeader` primitive, which carries
 * no horizontal padding of its own (deliberately — not every `Card`
 * context wants the same inset) and would need `className="px-4"` at every
 * call site anyway; one local pattern is what actually keeps both headers
 * identical.
 */
function SectionCardHeader({ icon: Icon, title, subtitle }) {
  return (
    <div className="px-4 py-3 border-b border-line">
      <h3 className="flex items-center gap-1.5 text-sm font-semibold text-ink">
        <Icon size={14} className="text-icon-2" /> {title}
      </h3>
      {subtitle && <p className="mt-0.5 text-xs text-ink-3">{subtitle}</p>}
    </div>
  );
}

/**
 * One insight, boxed on its own rather than a row in a shared list —
 * `break-inside-avoid` so the two-column layout below never slices a card
 * across the column break. Each can answer a follow-up about itself —
 * scoped to that card's own numbers, never the whole business — via a
 * deterministic responder (see ../lib/insights). No live model behind it
 * yet, so an unrecognized question gets an honest "don't have an answer
 * for that" rather than a guess.
 */
function InsightCard({ card }) {
  const Icon = INSIGHT_TONE_ICON[card.tone];
  const [asking, setAsking] = useState(false);
  const [question, setQuestion] = useState("");
  const [thread, setThread] = useState([]);

  const ask = () => {
    const q = question.trim();
    if (!q) return;
    setThread((t) => [...t, { q, a: answerInsightQuestion(card, q) }]);
    setQuestion("");
  };

  return (
    <div
      className={cx(
        "break-inside-avoid mb-3 rounded-md border p-3",
        TONE_CARD_CLASS[card.tone]
      )}
    >
      <div className="flex items-start gap-3">
        <span className={cx("shrink-0 mt-0.5", INSIGHT_TONE_ICON_CLASS[card.tone])}>
          <Icon size={15} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-ink">{card.title}</p>
          <p className="mt-0.5 text-xs text-ink-3 leading-relaxed">{card.detail}</p>

          {thread.length > 0 && (
            <div className="mt-2.5 space-y-2">
              {thread.map((t, i) => (
                <div key={i} className="text-xs">
                  <p className="font-medium text-ink-2">&ldquo;{t.q}&rdquo;</p>
                  <p className="mt-0.5 text-ink-3 leading-relaxed">{t.a}</p>
                </div>
              ))}
            </div>
          )}

          {asking ? (
            <div className="mt-2.5 flex items-center gap-1.5">
              <Input
                autoFocus
                value={question}
                placeholder="Ask about this…" onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && ask()}
                className="flex-1"
              />
              <Button size="sm" icon={Send} onClick={ask}>
                Ask
              </Button>
            </div>
          ) : (
            <button
              type="button" onClick={() => setAsking(true)}
              className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-ink-2 hover:text-ink hover:underline transition-colors"
            >
              <MessageCircle size={12} /> Ask about this
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------- Yield trend -- */

const CHART_W = 600;
const CHART_H = 100;
const CHART_PAD_X = 10;
const round1 = (n) => Math.round(n * 10) / 10;

/** Purpose-built for exactly this: "a small solid palette for per-person
 *  UI... deliberately its own hue family per swatch so it never gets
 *  mistaken for a status color at a glance" (see globals.css). A location
 *  is an identity here in the same sense a person is — never a status —
 *  so this, not ok/warn/danger, is the right palette to reach for. */
const SERIES_COLORS = [
  { stroke: "stroke-identity-1", fill: "fill-identity-1", dot: "bg-identity-1" },
  { stroke: "stroke-identity-2", fill: "fill-identity-2", dot: "bg-identity-2" },
  { stroke: "stroke-identity-3", fill: "fill-identity-3", dot: "bg-identity-3" },
  { stroke: "stroke-identity-4", fill: "fill-identity-4", dot: "bg-identity-4" },
];

/**
 * Every closed batch in view, oldest to newest, plotted by yield — a plain
 * SVG chart rather than a charting library, since this is the only chart in
 * the app so far. Points are dated on a real time axis (not evenly spaced
 * by index) so multiple locations' batches — closed on different days —
 * line up against a shared timeline instead of just a shared point count.
 *
 * One location in view: a single `ink` line — identity is ink when there's
 * only one, same rule the rest of the DNA uses for "you"/self. More than
 * one: each location gets its own colour from `SERIES_COLORS` (a fixed,
 * never-cycled order) plus a small legend, and this chart replaces what
 * used to be a separate "Locations" list card — the comparison now reads
 * off the lines themselves instead of a second list underneath them.
 *
 * Flagged batches (the same predicate the "Flagged" stat tile and
 * `locationStats` use, via `isFlaggedBatch`) get a slightly larger, `warn`
 * dot when there's only one series — with more than one, dots stay each
 * line's own colour so identity and status aren't fighting for the same
 * pixel; the flagged detail is still in the hover title and in the
 * narrative cards below. Hovering a point reveals the batch behind it via
 * a native `<title>` — deliberately not a custom tooltip, one more piece
 * of interactive state this screen doesn't need yet.
 */
function YieldTrendChart({ history, avg }) {
  const series = useMemo(() => {
    const byLocation = new Map();
    for (const h of history) {
      const y = yieldPct(h.boxWeight, h.finalWeight);
      if (y == null || !h.closedOn) continue;
      const key = h.locationId || "_all";
      const list = byLocation.get(key);
      const point = { ...h, y, flagged: isFlaggedBatch(h) };
      if (list) list.push(point);
      else byLocation.set(key, [point]);
    }
    return [...byLocation.entries()].map(([key, points], i) => ({
      key,
      name: points[0].locationName || null,
      color: SERIES_COLORS[i % SERIES_COLORS.length],
      points: points.sort((a, b) => (a.closedOn < b.closedOn ? -1 : a.closedOn > b.closedOn ? 1 : 0)),
      avg: round1(points.reduce((a, p) => a + p.y, 0) / points.length),
    }));
  }, [history]);

  const allPoints = series.flatMap((s) => s.points);
  if (allPoints.length < 2) {
    return (
      <p className="px-4 py-6 text-xs text-ink-4">
        Not enough closed batches yet to chart a trend — check back after a few more close out.
      </p>
    );
  }

  const multi = series.length > 1;

  const dates = allPoints.map((p) => new Date(`${p.closedOn}T00:00:00`).getTime());
  const dMin = Math.min(...dates);
  const dMax = Math.max(...dates);
  const dRange = dMax - dMin || 1;

  const ys = allPoints.map((p) => p.y);
  const yMin = Math.max(0, Math.min(...ys) - 5);
  const yMax = Math.min(100, Math.max(...ys) + 5);
  const yRange = yMax - yMin || 1;

  const scaleX = (closedOn) =>
    CHART_PAD_X + ((new Date(`${closedOn}T00:00:00`).getTime() - dMin) / dRange) * (CHART_W - CHART_PAD_X * 2);
  const scaleY = (y) => CHART_H - 6 - ((y - yMin) / yRange) * (CHART_H - 12);

  const avgY = typeof avg === "number" ? scaleY(avg) : null;
  const firstDate = allPoints.reduce((a, p) => (a.closedOn < p.closedOn ? a : p)).closedOn;
  const lastDate = allPoints.reduce((a, p) => (a.closedOn > p.closedOn ? a : p)).closedOn;

  return (
    <div className="px-4 py-3">
      <div className="flex items-center justify-between text-xs text-ink-3 mb-2">
        <span>{formatDay(firstDate)}</span>
        {avgY != null && <span className="text-ink-4">avg {avg}%</span>}
        <span>{formatDay(lastDate)}</span>
      </div>
      <svg
        viewBox={`0 0 ${CHART_W} ${CHART_H}`}
        preserveAspectRatio="none"
        className="w-full h-24"
        role="img"
        aria-label={`Yield across ${allPoints.length} closed batches, ${formatDay(firstDate)} through ${formatDay(lastDate)}`}
      >
        {avgY != null && (
          <line
            x1={0} y1={avgY} x2={CHART_W} y2={avgY}
            className="stroke-line-strong" strokeWidth={1} strokeDasharray="3 3"
          />
        )}
        {series.map((s) => {
          const line = s.points.map((p) => `${scaleX(p.closedOn)},${scaleY(p.y)}`).join(" ");
          return (
            <g key={s.key}>
              <polyline
                points={line}
                fill="none"
                className={multi ? s.color.stroke : "stroke-ink-2"}
                strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
              />
              {s.points.map((p, i) => (
                <circle
                  key={p.id || i}
                  cx={scaleX(p.closedOn)}
                  cy={scaleY(p.y)}
                  r={!multi && p.flagged ? 3.5 : 3}
                  className={multi ? s.color.fill : p.flagged ? "fill-warn" : "fill-ink"}
                >
                  <title>
                    {formatDay(p.closedOn)}
                    {s.name ? ` · ${s.name}` : ""} · {p.product} · {p.y}% yield{p.flagged ? " · flagged" : ""}
                  </title>
                </circle>
              ))}
            </g>
          );
        })}
      </svg>
      {multi && (
        <div className="flex items-center flex-wrap gap-x-4 gap-y-1.5 mt-3">
          {series.map((s) => (
            <span key={s.key} className="inline-flex items-center gap-1.5 text-xs text-ink-3">
              <span className={cx("w-2 h-2 rounded-full shrink-0", s.color.dot)} />
              {s.name || "Unknown location"}
              <span className="font-medium text-ink tnum">{s.avg}%</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * The console's landing screen — formerly a general Overview (onboarding
 * checklist, needs-attention list, locations at a glance), now dedicated to
 * insights, mirroring what used to be the shop floor's own Insights tab.
 *
 * Scoped by role rather than one fixed view: `insights` and `history` are
 * already pre-filtered by the caller (CompanyConsole) down to whatever
 * locations the signed-in user can see — every location for an admin, just
 * their own for a floor manager — so this component itself stays ignorant
 * of roles and just renders whatever scope it's handed. `scopeLabel`
 * describes that scope in the header (a location's name, or "company-wide").
 *
 * Two stacked cards below the stat grid: a yield trend across every closed
 * batch in view (one colour-coded line per location when there's more than
 * one, doubling as the locations comparison — no separate list for that),
 * and the original template-generated insight cards, each its own boxed,
 * tone-tinted card with its per-card "Ask about this" Q&A.
 */
export default function InsightsScreen({ scopeLabel, insights, history }) {
  const stats = useMemo(() => {
    const best = history.reduce((acc, h) => {
      const y = yieldPct(h.boxWeight, h.finalWeight);
      return y != null && (!acc || y > acc.y) ? { y, product: h.product } : acc;
    }, null);
    return {
      batches: insights.company.batches,
      avg: insights.company.avgYield != null ? insights.company.avgYield : "—",
      flagged: insights.company.flagged,
      best,
    };
  }, [history, insights]);

  return (
    <div>
      <StatGrid>
        <StatCard icon={History} label="Batches closed" value={stats.batches} />
        <StatCard
          icon={CheckCircle2}
          label="Average yield" value={stats.avg}
          unit={stats.avg !== "—" ? "%" : undefined}
          tone="primary"
        />
        <StatCard
          icon={AlertTriangle}
          label="Flagged" value={stats.flagged}
          tone={stats.flagged ? "warn" : "ok"}
          hint="low yield or slow"
        />
        <StatCard
          icon={TrendingUp}
          label="Best yield" value={stats.best ? `${stats.best.y}%` : "—"}
          tone="ok" hint={stats.best?.product}
        />
      </StatGrid>

      <StickyFadeHeader>
        <div className="flex items-center gap-2 flex-wrap">
          {scopeLabel && <p className="text-sm text-ink-3">{scopeLabel}</p>}
          <p className="text-sm text-ink-3">
            {insights.cards.length} insight{insights.cards.length === 1 ? "" : "s"}
          </p>
        </div>
      </StickyFadeHeader>

      <div className="space-y-6">
        <Card>
          <SectionCardHeader
            icon={TrendingUp}
            title="Yield trend"
            subtitle={
              insights.byLocation.length > 1
                ? "Every closed batch in view, oldest to newest — one line per location."
                : "Every closed batch in view, oldest to newest."
            }
          />
          <YieldTrendChart history={history} avg={typeof stats.avg === "number" ? stats.avg : null} />
        </Card>

        <Card>
          <SectionCardHeader
            icon={Sparkles}
            title="Insights"
            subtitle="Rolled up from closed batches — same numbers the floor sees, compared across whatever locations you have access to."
          />
          <div className="p-4">
            {insights.cards.length === 0 ? (
              <p className="text-xs text-ink-4">
                Insights show up once locations start closing batches on the floor.
              </p>
            ) : (
              <div className="sm:columns-2 gap-3">
                {insights.cards.map((card) => (
                  <InsightCard key={card.id} card={card} />
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
